'''
	Baseline Analysis of Movie Reviews
	Author : Joe Porter
'''

from p3lib import *
import sys
import os
from numpy import mean

lbMain = '<><><><><><><><><><><><><><><><><><><><><><><><>'
lbMax =  '================================================'
lbMin =  '-----------------------'

Dennis_train = 'DennisSchwartz_train.txt'
Scott_train = 'ScottRenshaw_train.txt'
Dennis_train_Para = 'DennisScwartz_none_merged.txt'
Scott_train_Para = 'ScottRenshaw_none_merged.txt'

print lbMain
print "Importing Dennis Schwartz Data"
dennis_revs = read_reviews(Dennis_train)
print "Dennis Schwartz imported"

print "Importing Scott Renshaw Data"
scott_revs = read_reviews(Scott_train)
print "Scott Renshaw data imported"

#Run Graham's Baseline
print lbMin
posWords = getWordLists("positiveWords.txt")
negWords = getWordLists("negativeWords.txt")

print "Getting Graham's Baseline Predictions for Dennis Data"
dennis_bPred = classifyByWords(posWords, negWords, dennis_revs) 
print "Getting Graham's Baseline Predictions for Scott Data"
scott_bPred = classifyByWords(posWords, negWords, scott_revs)

#Get Actual Sentence Level Sentiments
print lbMin
print "Getting sentiment tags from Dennis"
dennis_aPred = review_tagSequences(dennis_revs)
print "Getting sentiment tags from Scott"
scott_aPred = review_tagSequences(scott_revs)

#Get the Document Level Mean Sentiment Scores (Sentence-Level)
print lbMin
print "Getting Mean Document Level Sentiments (Sentence Based) for Dennis"
dennis_bPred_means = get_docLevelMeanSentTags(dennis_bPred)
print "Getting Mean Document Level Sentiments (Sentence Based) for Scott"
scott_bPred_means = get_docLevelMeanSentTags(scott_bPred)

#Map to Respective Scores
#Dennis has 18 States thus each .27 is a state for Dennis
dennis_bPred_score = convert2Dennis(dennis_bPred_means)
#Scott has 10 States thus each .5 is a state for Scott
scott_bPred_score = convert2Scott(scott_bPred_means)

#Get Grades from Training Data
#print "Getting Grades from Training Data"
scottGrades = getGrades(scott_revs)
dennisGrades = getGrades(dennis_revs)

#Get the RMSquared error
scott_rmserror = altrmserror(scott_bPred_score, scottGrades)
dennis_rmserror = altrmserror(dennisAcc(dennis_bPred_score), dennisAcc(dennisGrades))

print lbMin
print "Scott RMSError: " + str(scott_rmserror)
print "Dennis RMSError: " + str(dennis_rmserror)

dennisMax = 9
scottMax = 8
scott_accuracy = altAccuracy(scott_bPred_score, scottGrades, scottMax)
dennis_accuracy = altAccuracy(dennisAcc(dennis_bPred_score), dennisAcc(dennisGrades), dennisMax)

print lbMin
print "Scott Accuracy: " + str(scott_accuracy)
print "Dennis Accuracy: " + str(dennis_accuracy)

print lbMax
print "Getting HMM Predictions for Dennis Data"
labeled_sequences = list()
states = ['a+', 'a', 'a-', 'b+', 'b', 'b-', 'c+', 'c', 'c-', 'd']
observed_states = states

trainer = nltk.tag.hmm.HiddenMarkovModelTrainer(states, observed_states)
for i in range(len(dennis_bPred)):
    labeled_sequences.append(zip(dennis_bPred[i],dennisGrades))

tagger = trainer.train_supervised(labeled_sequences)

tagged = tagger.batch_tag(dennis_bPred)

