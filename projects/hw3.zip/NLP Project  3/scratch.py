'''
Created on Apr 5, 2013

@author: Graham Harwood
'''
import p3lib
import nltk.tag.hmm
from nltk.corpus import stopwords
import os
'Takes in the output of read reviews and returns a list of lists where the first list is the review'
'the second list is a list of sentiments associated with each sentence of that review in order'
def reviewsToSentimentList(reviews):
    #print 'in reviews to sentiment'
    reviewList=[]
    for rev in reviews:
        sentiList=[]
        for x in range(0, len(rev['paragraphs'])):
            for sent in rev['paragraphs'][x]['sentences']:
                sentiList.append(sent['sentTag'])
        reviewList.append(sentiList)
    return reviewList


'Helper method for pathProbs'
'Converts everything to probabilities'
def listToProb(rlist):
    #print str(len(dict))
    sum=0.0
    nList=[]
    for x in range(0, len(rlist)):
        sum+=rlist[x]
    for y in rlist:
        if sum > 0:
            nList.append(float(y/sum))
        else:
            nList=[0, 0, 0, 0, 0]
    return nList


'Takes the review list and creates a list of lists where each review has a list of probabilities for what the next sentiment will be given the current sentiment'
' -2 (N2) is index 0 and so on up to 2 being index 4'
def pathProbs(reviewList):
    #print reviewList
    #counter=0
    lN2=[0, 0, 0, 0, 0] #It was easier to initialize these
    lN1=[0, 0, 0, 0, 0]
    l0=[0, 0, 0, 0, 0]
    l1=[0, 0, 0, 0, 0]
    l2=[0, 0, 0, 0, 0]
    reviewLinkProbs=[lN2, lN1, l0, l1, l2,] # initialize final list 
    for x in range(0, len(reviewList)):
        lN2=[0, 0, 0, 0, 0]#Resets so its a new model for each review
        lN1=[0, 0, 0, 0, 0]
        l0=[0, 0, 0, 0, 0]
        l1=[0, 0, 0, 0, 0]
        l2=[0, 0, 0, 0, 0]
        
        for y in range(0, len(reviewList[x])-2): #prevents from going to the next sentence after the last review
            #counter+=1
            reviewList[x][y]=float(reviewList[x][y])
            reviewList[x][y+1]=int(reviewList[x][y+1])
            index=reviewList[x][y+1]+2 #Gives a variable index where the value should be added
            if reviewList[x][y] == -2:
                #print "neg 2"
                lN2[index]+=1
            elif reviewList[x][y] == -1:
                #print "neg 1"
                lN1[index]+=1
            elif reviewList[x][y] == 0:
                #print "is 0"
                l0[index]+=1
            elif reviewList[x][y] == 1:
                l1[index]+=1
            elif reviewList[x][y] == 2:
                #print "is 2"
                l2[index]+=1
        pathProbList=[lN2, lN1, l0, l1, l2,]
        for x in range(0, len(pathProbList)): #adds from the temp list to the final list
            for y in range(0, len(pathProbList[x])):
                    reviewLinkProbs[x][y]+=pathProbList[x][y]
    #lN2=listToProb(lN2)
    #lN1=listToProb(lN1)
    #l0=listToProb(l0)
    #l1=listToProb(l1)
    #l2=listToProb(l2)
        for z in range(0, len(reviewLinkProbs)): #convert lists of occurences to probabilities
            reviewLinkProbs[z]=listToProb(reviewLinkProbs[z])
    #print counter
    return reviewLinkProbs



'Scratch Space Unsure of difference but does not function correctly'
def altPathProbs(reviewList):
    lN2=[0, 0, 0, 0, 0]
    lN1=[0, 0, 0, 0, 0]
    l0=[0, 0, 0, 0, 0]
    l1=[0, 0, 0, 0, 0]
    l2=[0, 0, 0, 0, 0]
    for x in range(0, len(reviewList)):
        for y in range(0, len(reviewList[x])-1):
            reviewList[x][y]=int(reviewList[x][y])
            reviewList[x][y+1]=int(reviewList[x][y+1])
            index=reviewList[x][y+1]+2
            if reviewList[x][y] == -2:
                #print "neg 2"
                lN2[index]+=1
            elif reviewList[x][y] == -1:
                #print "neg 1"
                lN1[index]+=1
            elif reviewList[x][y] == 0:
                #print "is 0"
                l0[index]+=1
            elif reviewList[x][y] == 1:
                l1[index]+=1
            elif reviewList[x][y] == 2:
                #print "is 2"
                l2[index]+=1
    lN2p=listToProb(lN2)
    lN1p=listToProb(lN1)
    l0p=listToProb(l0)
    l1p=listToProb(l1)
    l2p=listToProb(l2)
    pathProbList=[lN2p, lN1p, l0p, l1p, l2p]
    return pathProbList
   
def getWordLists(listLoc):
    words=open(listLoc, "rb").readlines()
    for x in range(0, len(words)):
        words[x]=nltk.word_tokenize(words[x])
        words[x]=words[x][0].lower()
    return words

def classifyByWords(posWords, negWords, reviews):      
    senseList=[]

    for rev in reviews: # for each review
        revList=[]
        for x in range(0, len(rev['paragraphs'])): # for each paragraph
            for sent in rev['paragraphs'][x]['sentences']: # for each sentence
                sentScore=0.0
                s=nltk.word_tokenize(sent['sentence'])
                #print sent['sentence']
                for y in s:
                    y=y.lower()
                    if y in posWords:
                        sentScore+=1.0
                    elif y in negWords:
                        sentScore-=1.0
                if sentScore==-1:
                    #print "entered here"
                    revList.append(-1)
                elif sentScore==0:
                    revList.append(0)
                elif sentScore==1:
                    revList.append(1)
                elif sentScore<-1:
                    revList.append(-2)
                else:
                    revList.append(2)
        senseList.append(revList)
    return senseList

def addBases(scottBase, gBase):
    revList=[]
    for x in range(0,len(scottBase)):
        labeledTypes=[]
        for y in range(0,len(scottBase[x])):
            labeledTypes.append(str(scottBase[x][y]) + str(gBase[x][y]))
        revList.append(labeledTypes)
    return revList

def outputToFile(testBase, filename):
    if os.path.exists(filename):
        os.remove(filename)
    output=open(filename, "a")
    for x in range(0, len(testBase)):
        for y in range(0, len(testBase[x])):
            output.write(testBase[x][y][1] + "\n")


def sentenceLengthWords(reviews):
    senseList=[]
    for rev in reviews: # for each review
        revList=[]
        for x in range(0, len(rev['paragraphs'])): # for each paragraph
            for sent in rev['paragraphs'][x]['sentences']: # for each sentence
                s=nltk.word_tokenize(sent['sentence'])
                revList.append(str(len(s)))
        senseList.append(revList)
    return senseList  
                
def sentenceLengthChars(reviews):
    senseList=[]
    for rev in reviews: # for each review
        revList=[]
        for x in range(0, len(rev['paragraphs'])): # for each paragraph
            for sent in rev['paragraphs'][x]['sentences']: # for each sentence
                s=sent['sentence']
                revList.append(str(len(s)))
        senseList.append(revList)
    return senseList
#If you would like to test
print "Started"
reviews= p3lib.read_reviews('ScottRenshaw_train.txt')
reviewList = reviewsToSentimentList(reviews)
posWords=getWordLists('positiveWords.txt')
negWords=getWordLists('negativeWords.txt')

#print altPathProbs(reviewList)
gBase=classifyByWords(posWords, negWords, reviews)
testReviews=p3lib.read_reviews('ScottRenshaw_test.txt')
gTestBase=classifyByWords(posWords, negWords, testReviews)
observedStates=[]
for x in range(-2,3):
    for y in range(-2,3):
        strr=''
        strr+= str(x) + str(y)
        observedStates.append(strr)

aPred = p3lib.review_tagSequences(reviews)

states=['-2','-1','0','1','2']
fDist=p3lib.gen_corpus('ScottRenshaw_train.txt')
revs=p3lib.read_reviews('ScottRenshaw_train.txt')
topW=p3lib.baseline_features(revs, 30, fDist, 50)
scottBase=p3lib.baseline_prediction(topW, revs)
testRevs=p3lib.read_reviews('ScottRenshaw_test.txt')
testScottBase=p3lib.baseline_prediction(topW, testRevs)
transProbs=pathProbs(reviewList)
lWtrain = sentenceLengthWords(reviews)
lCtrain = sentenceLengthChars(reviews)
#print str(len(scottBase))
#print str(len(gBase))
#testStates=addBases(testScottBase, gTestBase)
#observed = addBases(scottBase,gBase)
labeled_sequences = list()
labeled_sequencesC = list()
lWtrain= addBases(lWtrain, lCtrain)
#print str(len(observed))
#print str(len(aPred))
#testStates=p3lib.review_tagSequences(revs)

for i in range(len(lWtrain)):
    labeled_sequences.append(zip(lWtrain[i],aPred[i]))

for i in range(len(lCtrain)):
    labeled_sequencesC.append(zip(lCtrain[i],aPred[i]))

trainer=nltk.tag.hmm.HiddenMarkovModelTrainer(states, observedStates)

tagger = trainer.train_supervised(labeled_sequences)
taggerC = trainer.train_supervised(labeled_sequencesC)

lWtest = sentenceLengthWords(testReviews)
lCtest = sentenceLengthChars(testReviews)
lWtest = addBases(lWtest, lCtest)

tagged = tagger.batch_tag(lWtest)
taggedC = tagger.batch_tag(lCtest)


predlist=list()
#for review in tagged:
#    innerlist=list()
#    for sent in review:
#        innerlist.append(sent[1])
#    predlist.append(innerlist)
#print str(p3lib.accuracy(aPred, gBase))

outputToFile(tagged, 'hmmresultsW.txt')
outputToFile(taggedC, 'hmmresultsC.txt')

#print sentenceLengthWords(reviews)
#print sentenceLengthChars(reviews)
'''for t in tagged:
    for a in t:
        if a[1] != '0':
            print a[1]'''



