'''
	Baseline Analysis of Movie Reviews
	Author : Scott Cambo
'''

from p3lib import *
import sys
import os
from numpy import mean

lbMain = '<><><><><><><><><><><><><><><><><><><><><><><><>'
lbMax =  '================================================'
lbMin =  '-----------------------'

Dennis_train = 'DennisSchwartz_train.txt'
Dennis_test = 'DennisSchwartz_test.txt'
Scott_train = 'ScottRenshaw_train.txt'
Scott_test = 'ScottRenshaw_test.txt'
numClassTopWords = 20
numOverallWords = 50

kFold = 5
#def cross_val_Acc(revs, kFold):
#	accuracyList = []
#	for i in range(1,kFold +1):
#		kSplits = kFold_Split(revs, kFold, i)
#		trainRevs = kSplits[0]
#		valRevs = kSplits[1]


print lbMain
print "Importing Dennis Schwartz Data"
dennis_revs = read_reviews(Dennis_train)
print "Dennis Schwartz imported"
print "Importing Scott Renshaw Data"
scott_revs = read_reviews(Scott_train)
print "Scott Renshaw data imported"

print lbMax
print "Generate Dennis Schwartz Corpus from training data"
dennis_corpus = gen_corpus(Dennis_train)
print "Generate Scott Renshaw Corpus from training data"
scott_corpus = gen_corpus(Scott_train)

# Cross-Validation Section
dennis_accuracyList = []
scott_accuracyList = []
dennis_rmserrorList = []
scott_rmserrorList = []

print lbMax
print "Starting " + str(kFold) + " Cross-Validation"
print lbMax
for i in range(0, kFold):

	Dennis_kSplits = kFold_Split(dennis_revs, kFold, i)
	Dennis_train = Dennis_kSplits[0]
	Dennis_val = Dennis_kSplits[1]

	Scott_kSplits = kFold_Split(scott_revs, kFold, i)
	Scott_train = Scott_kSplits[0]
	Scott_val = Scott_kSplits[1]

	print lbMax
	print "Starting the " + str(i)  + " fold computation"
	print lbMin
	print "Compute baseline features for Dennis using all training data"
	dennis_topW = baseline_features(Dennis_train, numClassTopWords, dennis_corpus, numOverallWords)
	print "Compute baseline features for Scott using all training data"
	scott_topW = baseline_features(Scott_train, numClassTopWords, scott_corpus, numOverallWords)

	print lbMin
	print "Get sentiment tags from Dennis"
	dennis_aPred = review_tagSequences(Dennis_val)
	print "Get sentiment tags from Scott"
	scott_aPred = review_tagSequences(Scott_val)

	print lbMin
	print "Generate baseline predictions for Dennis"
	dennis_bPred = baseline_prediction(dennis_topW, Dennis_val)
	print "Generate baseline predictions for Scott"
	scott_bPred = baseline_prediction(scott_topW, Scott_val)

	print lbMin
	print "Compute accuracy and RMS error for Dennis classifier"
	print "bPred : " + str(len(dennis_bPred)) + ", aPred : " + str(len(scott_aPred))
	dennis_acc = accuracy(dennis_aPred, dennis_bPred)
	dennis_accuracyList.append(dennis_acc)
	dennis_rms = rmserror(dennis_aPred, dennis_bPred)
	dennis_rmserrorList.append(dennis_rms)
	print "Compute accuracy and RMS error for Scott classifier"
	scott_acc = accuracy(scott_aPred, scott_bPred)
	scott_accuracyList.append(scott_acc)
	scott_rms = rmserror(scott_aPred, scott_bPred)
	scott_rmserrorList.append(scott_rms)
	print "\t Dennis : " + str(dennis_acc) + "% accurate, " + str(dennis_rms) + " RMS error"
	print "\t Scott : " + str(scott_acc) + "% accurate, " + str(scott_rms) + " RMS error"

# compute mean accuracy
print lbMax
dennis_meanAcc = mean(dennis_accuracyList)
dennis_meanRMS = mean(dennis_rmserrorList)
scott_meanAcc = mean(scott_accuracyList)
scott_meanRMS = mean(scott_rmserrorList)
print "Final Mean Accuracy and RMS Error"
print "\t Dennis : " + str(dennis_meanAcc) + "% accurate, " + str(dennis_meanRMS) + " RMS error"
print "\t Scott : " + str(scott_meanAcc) + "% accurate, " + str(scott_meanRMS) + " RMS error"
