'''
	Train and test on scott renshaw and Dennis Schwartz data
	Author : Scott Cambo
'''

from p3lib import *
import sys
import os

lbMain = '<><><><><><><><><><><><><><><><><><><><><><><><>'
lbMax =  '================================================'
lbMin =  '-----------------------'

Dennis_train = 'DennisSchwartz_train.txt'
Dennis_test = 'DennisSchwartz_test.txt'
Dennis_predOutLoc = 'DennisSchwartz_predictions.txt'
Scott_train = 'ScottRenshaw_train.txt'
Scott_test = 'ScottRenshaw_test.txt'
Scott_predOutLoc = 'ScottRenshaw_predictions.txt'

numClassTopWords = 30
numOverallWords = 50

print lbMain
print "Importing Dennis Schwartz Data"
dennis_revs = read_reviews(Dennis_train)
dennis_testRevs = read_reviews(Dennis_test)
print "Dennis Schwartz imported"
print "Importing Scott Renshaw Data"
scott_revs = read_reviews(Scott_train)
scott_testRevs = read_reviews(Scott_test)
print "Scott Renshaw data imported"

print lbMax
print "Generate Dennis Schwartz Corpus from training data"
dennis_corpus = gen_corpus(Dennis_train)
print "Generate Scott Renshaw Corpus from training data"
scott_corpus = gen_corpus(Scott_train)

print lbMax
print "Compute baseline features for Dennis using all training data"
dennis_topW = baseline_features(dennis_revs, numClassTopWords, dennis_corpus, numOverallWords)
print "Compute baseline features for Scott using all training data"
scott_topW = baseline_features(scott_revs, numClassTopWords, scott_corpus, numOverallWords)

#print lbMax
#print "Get sentiment tags from Dennis"
#dennis_aPred = review_tagSequences(dennis_revs)
#print "Get sentiment tags from Scott"
#scott_aPred = review_tagSequences(scott_revs)

print lbMax
print "Generate baseline predictions for Dennis"
dennis_bPred = baseline_prediction(dennis_topW, dennis_testRevs)
print "Generate baseline predictions for Scott"
scott_bPred = baseline_prediction(scott_topW, scott_testRevs)

print lbMax
print "Writing predictions for Dennis out to " + Dennis_predOutLoc
Dennis_outFile = open(Dennis_predOutLoc, "w")
for rev in dennis_bPred:
	for tag in rev:
		Dennis_outFile.write(tag + "\n")

Dennis_outFile.close()

print "Writing predictions for Scott out to " + Scott_predOutLoc
Scott_outFile = open(Scott_predOutLoc, "w")
for rev in scott_bPred:
	for tag in rev:
		Scott_outFile.write(tag + "\n")

Scott_outFile.close()
