import nltk.tag.hmm
import p3lib

'''states = ['-2','-1','0','1','2']
observed_states = ['A','B']

trainer = nltk.tag.hmm.HiddenMarkovModelTrainer(states,observed_states)

labeled_sequences = [[('A','-2'),('B','0')],
                     [('A','-2'),('B','0'),('A','-1')],
                     [('B','0'),('A','-2')]]

tagger = trainer.train_supervised(labeled_sequences)

print tagger.tag(['A','B'])'''

# build a corpus from jennifer's code
train = "C:\Users\Jennifer\workspace\NLP Project 3\DennisSchwartz_train.txt"
corpus = p3lib.gen_corpus(train)

#organize reviews into datastructure
revs = p3lib.read_reviews(train)

# get features for baseline predictions
topW = p3lib.baseline_features(revs, 30, corpus, 50)

# make baseline predictions
bPred = p3lib.baseline_prediction(topW, revs)

# get actual tag sequence
aPred = p3lib.review_tagSequences(revs)

#dictPred = ....

'''print bPred
print aPred'''

'''a = [['a','b','c'],['d','e'],['f']]
b = [['1','2','3'],['4','5'],['6']]'''

labeled_sequences = list()

for i in range(len(bPred)):
    labeled_sequences.append(zip(bPred[i],aPred[i]))
print labeled_sequences

states = ['-2','-1','0','1','2']
observed_states = states

trainer = nltk.tag.hmm.HiddenMarkovModelTrainer(states,observed_states)

tagger = trainer.train_supervised(labeled_sequences)

#The 1st sentence of the 3rd paragraph of the 5th review would be accessed like:
        #revs[4]['paragraphs'][2]['sentences'][0]['sentence']
        
#revs[reviewNum]['paragraphs'][paraNum]['sentences'][sentenceNum]['sentence']
#print bPred[0]
'''for s in bPred:
    print s'''

tagged = tagger.batch_tag(bPred)

for t in tagged:
    for a in t:
        if a[1] != '0':
            print a[1]



#labeled_sequences = []

