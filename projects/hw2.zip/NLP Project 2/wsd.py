import re
import nltk
import time
from nltk.tokenize import word_tokenize
from nltk.stem.wordnet import WordNetLemmatizer

global dataLoc # Location of provided data
global submissionLoc # Location of output file for Kaggle
global submit # Output file
global threshold # Threshold of maximum overlap value for a sense to be considered "correct"
global punctuation # List of punctuation characters

dictLoc = "../Dictionary.xml" # Location of XML dictionary file
dataLoc = "../Test Data.data" 
submissionLoc = "../submission.csv"
threshold = 0.99
punctuation = ['.',',','!','?','(',')','$','%','&','\'','"']
xmlDict = {}

# Returns a dictionary of the following form:
#    word1 : [synset1:... gloss1:..., synset2:... gloss2:..., ... ]
#    word2 : [synset1:... gloss1:..., synset2:... gloss2:..., ... ]
#    ...
# Key is word (like 'begin.v'), and value is list of senses.
# Index of sense within list corresponds to order in dictionary.
# Each sense is represented by a dictionary with key 'synset' for synonym set
# and key 'gloss' for definition
def getDict():
    xml = open(dictLoc).read()
    dictionary = dict()
    for i in re.findall(r"<lexelt item=.*?</lexelt>",xml,re.DOTALL): # for each lexelt element
        item = re.match(r'<lexelt item="(?P<item>.*)">', i)
        senses=[]
        for s in re.findall(r"<sense.*?/>",i): # for each sense
            sense = re.match(r'<sense.*?synset="(?P<synset>.*?)" gloss="(?P<gloss>.*?)"/>', s).groupdict()
            senses.append(sense)
        dictionary[item.group('item')] = senses
    return dictionary

# Runs Lesk's Algorithm in order to compute the best sense of the word in a given context
# Takes in a single word as a string and a string of words as arguments
# Runs compute_overlap and returns the sense definition with the largest overlap
# Also writes results (0 or 1 per line) to submission file
def lesk_algo(word, sentence): 
    global xmlDict
    xmlDict = getDict()
    
    sent_no_word = re.sub("@.*?@","",sentence)
    context = word_tokenize(sent_no_word)

    senses = get_xml_senses(word)
    if not senses:
        return "There are no senses available for the word: " + word + "\n"
    best_sense = senses[0]
    max_overlap = 0
    output = []

    for sense in senses:
        overlap = compute_overlap(get_signature(sense), context)
        output.append(overlap)
        if overlap > max_overlap:
            max_overlap = overlap
            best_sense = sense
    if max_overlap == 0: # If no overlap, write 1 for "unknown/undecided"
        submit.write('1\n')
    elif all(val/float(max_overlap) > threshold for val in output): # If all senses are considered "correct", write 1 for "unknown/undecided"
        submit.write('1\n')
    else: # Write 0 for "unknown/undecided"
        submit.write('0\n')
    for val in output:
        if max_overlap == 0: # If no overlap for any sense, write 0
            submit.write('0\n')
        elif val/float(max_overlap) > threshold: # If overlap exceeds relative threshold of max overlap, write 1
            submit.write('1\n')
        else: # Overlap beneath threshold, write 0
            submit.write('0\n')
    return best_sense['gloss']

# Computes the overlap between the context and the dictionary entries for a word
# Returns the score for overlap
def compute_overlap(signature, context):
    overlap = 0
    #Imports the stopwords from stopword corpus
    stopwords = nltk.corpus.stopwords.words('english')
    #Makes an instance of the lemmatizer
    lmtzr = WordNetLemmatizer()
    def_arr = []
    new_context = []
    for c in context:
        word = c.lower()
        if word not in stopwords and word not in punctuation:
            new_context.append(word)
    for c in new_context:
        word = lmtzr.lemmatize(c)
        overlap, def_arr = overlap_helper(word, signature, stopwords, lmtzr, def_arr, overlap)
    return overlap

# Uses xml file to find all the senses of a given word
def get_xml_senses(word):
    return xmlDict[word]

# For a given sense, returns the dictionary definition and the examples for that sense
def get_signature(sense):
    return (sense['gloss'],sense['synset'])

# A helper for the compute overlap function.
# Takes in a term from the dictionary and the context.
# Takes in the stopwords, lemmatizer object and the old array
# Returns a number that is used for the overlap and the new array.
def overlap_helper(term, signature, stopwords, lem, old, old_overlap): 
    new = []
    index = 0
    overlap = old_overlap
    gloss, synset = signature
    
    tokenized_sense = word_tokenize(gloss)
    tokenized_sense.extend(word_tokenize(synset))
    
    for s in tokenized_sense:
        word = s.lower()
        if word not in stopwords and word not in punctuation:
            if term.lower() == lem.lemmatize(word).lower():
                found = False
                for (ind, succ) in old:
                    if ind == index:
                        found = True
                        tup = (index +1, succ + 1)
                        new.append(tup)
                        overlap = overlap + (2 ** succ)
                if not found:
                    tup = (index + 1, 1)
                    new.append(tup)
                    overlap = overlap + 1
        index = index + 1
    return (overlap, new) 

# Times and runs Lesk's algorithm for each line in dataLoc
if __name__ == "__main__":
    t0 = time.clock()
    print("Started at ")
    print(time.asctime())
    print("\n")
    data = open(dataLoc)
    submit = open(submissionLoc, 'w')
    count = 1
    for d in data:
        m = re.match(r'(?P<word>\w+\.\w+).*?@\s*(?P<context>.*)', d)
        example = m.groupdict()
        lesk_algo(example["word"], example["context"])
        if count%250 == 0:
            print(str(count))
        count += 1
    t1 = time.clock()
    diff = t1-t0
    print("Completed after ")
    print(str(diff/float(60)))
    print(" minutes")
    submit.close()     
