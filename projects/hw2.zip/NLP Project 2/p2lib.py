# Project 2 Library
import os
from supervisedModel import wordModel
import random as rand
import numpy as np
linebreak1="><><><><><><><><><><><><><><><><><><><><><><><"
linebreak2="//////////////////////////////////////////////"
linebreak3="----------------------------------------------"

def buildWordModels(wordData, windowSize):
    wordModels=dict()
    for x in wordData:
    	keyword=x['keyword']
        if keyword in wordModels:
            wordModels[keyword].occured()
            fVector=wordModels[keyword].contextStringToTokensOnWindow(x['context'])
            for y in range(0, len(x['senses'])-1):
                if x['senses'][y] == 1:
                	wordModels[keyword].senses[y]+=1
                	wordModels[keyword].increContextSense(y, fVector)
        else:
        	wordModels[keyword]=wordModel([keyword], windowSize)
        	wordModels[keyword].setSenses(len(x['senses']))
        	wordModels[keyword].buildContextSenses()
        	wordModels[keyword].occured()
        	fVector=wordModels[keyword].contextStringToTokensOnWindow(x['context'])
        	
        	for y in range(0, len(x['senses'])-1):
        		if x['senses'][y] == 1:
        			wordModels[keyword].senses[y]+=1
        			wordModels[keyword].increContextSense(y, fVector)
    for z in wordModels:
    	wordModels[z].setSenseProb()  
    return wordModels

def testFromDict(testData, wordModels):
	senseList=list()
	for test in testData:
		sProbs=wordModels[test['keyword']].bayesProb(test['context'])
		senseList.append(wordModels[test['keyword']].senseDecider(sProbs))
	return senseList

def outputSenseList(senseList):
	filename="results.txt"
	#exists=os.path.exists(filename)
	if os.path.exists(filename):
		os.remove(filename)
	output=open(filename, "a")
	for x in range(0, len(senseList)):
		for y in senseList[x]:
			output.write(str(y) + "\n")
	#for z in range(0,4):
	#	output.write(str(0) + "\n")


def parse(file_loc):
	'''Takes in a string representing the relative location of the training (or test) text,
	then parses the text to a list where each cell is a dictionary for a training line
	with keys as 'keyword', 'pos', 'senses' (a list of the sense), and 'context'.  It will
	also return as part of a tuple, a dictionary in which each keyword is the key and each
	value is the training data for that specific word
	'''
	Text = open(file_loc, "r")
	listSet = []
	dictSet = dict()
	currWord = '' #keeping track of the current word being processed
	for line in Text:
		trainingCase = dict()
		header = line.split("@")[0].split(" ")
		word = header[0].split(".")[0]
		pos = header[0].split(".")[1]
		senses = []
		for i in range(1,len(header[1:])):
			senses.append(int(header[i]))
		context = "@".join(line.split("@")[1:]).strip()
		trainingCase = {"keyword":word, "pos":pos, "senses":senses, "context":context}
		listSet.append(trainingCase)
		if word is not currWord:
			currWord = word
			if word not in dictSet:
				dictSet[word] = [trainingCase]
			else:
				dictSet[word].append(trainingCase)
	return listSet, dictSet

def betterTrain(wordData, maxWin):
	windowDict = {} 
	totalWords = len(wordData)
	j=1
	percentTrain = .9
	for word in wordData:

		bestAcc = 0
		bestWin = maxWin+1
		#print "---------------"
		#print wordData[word]
		#print "---------------"
	#print
		total = len(wordData[word])
		numTrain = int(total * percentTrain)
		numVal = int(total - numTrain)
		print linebreak3
		print "Total is " + str(total)
		print "Training set is " + str(numTrain)
		print "Validation set is " + str(numVal)
		for win in range(maxWin, 0, -1):
			#kwTrain = wordData[word][:-1]
			#kwVal = [wordData[word][-1]]
			accList = [] #store accuracy results

			#cross validate with random sampling
			for k in range(0, 3):
				trains = []
				vals = []
				truth = []
				for tr in range(0, numTrain):
					trains.append(rand.choice(wordData[word]))
				for v in range(0, numVal):
					vals.append(rand.choice(wordData[word]))
				for v in vals:
					truth.append(v['senses'])
				wordModel = buildWordModels(trains, win)
				predList = testFromDict(vals, wordModel)
				accuracy = accuracyMetrics(predList, truth)
				accList.append(accuracy)
			meanAcc = np.mean(accList)
			#wordModel = buildWordModels(kwTrain, i)
			#predList= testFromDict(kwVal, wordModel)
			#truth = [kwVal[0]['senses']]
			#accuracy = accuracyMetrics(predList, truth)
			if meanAcc >= bestAcc :
				bestAcc = meanAcc
				bestWin = win
		windowDict[word] = bestWin
		print word + " : " + str(bestAcc) + "% , win is " + str(bestWin) + ", " + str(j) + "/" + str(totalWords)
		j+=1
	#print windowDict
	return windowDict
	     #   print linebreak3
	        #print "Truth is " + str(truth)
	      #  print linebreak2
	        #print "Accuracy = " + str(accuracy)
	    #print linebreak3
	    #print "Best Accuracy was " + str(bestAcc) + "% at " + str(bestWin)
	    #print linebreak3

def accuracyMetrics(predSet, trueSet):

    #Set Vars
    truePos, falsePos, trueNeg, falseNeg, total = (0,)*5
    precision, recall, accuracy =(0,)*3

    #For each senses list
    for s in xrange(0, len(predSet)):
        #print s
        #For each elm in the senses list
        for c in xrange(0, len(predSet[s])):
           
            #Compute Total
            total += 1

            #If the values match, increase truePos or trueNeg
            if predSet[s][c] == trueSet[s][c]:
                    truePos += 1

    accuracy = float(truePos) / float(total) * 100.00
    #Return a dictionary with key being the metric and their respective values
    return accuracy

def buildWordModelsDict(wordData, windowDict):
	#print "length of wordData in build is " + str(len(wordData))
	wordModels=dict()
	for x in wordData:
		keyword=x['keyword']
		#print "keyword is " + keyword
		if keyword in wordModels:
			#print "In the if statement"
			wordModels[keyword].occured()
			fVector=wordModels[keyword].contextStringToTokensOnWindow(x['context'])
			for y in range(0, len(x['senses'])-1):
				if x['senses'][y] == 1:
					wordModels[keyword].senses[y]+=1
					wordModels[keyword].increContextSense(y, fVector)
		else:
			#print "In the else statement"
			wordModels[keyword]=wordModel([keyword], windowDict[keyword])
			wordModels[keyword].setSenses(len(x['senses']))
			wordModels[keyword].buildContextSenses()
			wordModels[keyword].occured()
			fVector=wordModels[keyword].contextStringToTokensOnWindow(x['context'])
			
			for y in range(0, len(x['senses'])-1):
				if x['senses'][y] == 1:
					wordModels[keyword].senses[y]+=1
					wordModels[keyword].increContextSense(y, fVector)
	for z in wordModels:
		wordModels[z].setSenseProb()
	return wordModels
