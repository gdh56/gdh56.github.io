'''
Created Feb. 23
@author: Scott Cambo, Graham Harwood, Jennifer Doughty, Malcolm Mckinney

CS 4740 : Natural Language Processing
Project 1

'''

import pickle
import sys
from supervisedModel import wordModel
import p2lib as p2
import pylab as pl
import random as rand
import numpy as np
linebreak1="><><><><><><><><><><><><><><><><><><><><><><><"
linebreak2="//////////////////////////////////////////////"
linebreak3="----------------------------------------------"


def act1():
    print linebreak3
    print "Welcome to Dictionary Based Disambiguation:\n"
    print "Please input the directory of the dictionary file you would like to parse and press ENTER\n"
    dictionaryInfo=raw_input("Dictionary: ")
    #Malcolm and Jennifer I am not sure how you handle the rest. We can work in pickle stuff if the runtime is excessive


def act2():
    print linebreak3
    print "Welcome to Naive Bayes Disambiguation: "
    file_loc=raw_input("What file would you like to train on? Type in the path and press ENTER\n")
    wordData=p2.parse(file_loc)
    wordModels=p2.buildWordModels(wordData[0], 1)
    print linebreak2
    print "Model Trained"
    print linebreak2
    test_loc=raw_input("Please input the test file location and press ENTER\n")
    inDict=p2.parse(test_loc)
    senseList=p2.testFromDict(inDict[0], wordModels)
    print senseList
    p2.outputSenseList(senseList)
    
def trainOneWord():
    print linebreak3
    maxWin = 20
    "Analysis of Single Word Window Change"
    file_loc=raw_input("What file would you like to train on? Type in the path and press ENTER\n")
    wordData=p2.parse(file_loc)
    i = 0
    kwList = []
    kw = {}
    for w in wordData[1]:
        print str(i) + ") " + w
        kwList.append(w)
        if i < 10 :
            i += 1
        else:
            break

    wordNum = int(raw_input("Type in the number of the word that you would like to use below\n"))
    kw = wordData[1][kwList[wordNum]]
    numTrain = len(kw) - 2
    kwTrain = kw[:-1]
    kwVal = [kw[-1]]
    bestAcc = 0
    bestWin = maxWin + 1
    accDict = {}
    print
    for i in range(maxWin, 0, -1):
        wordModel = p2.buildWordModels(kwTrain, i)
        predList= p2.testFromDict(kwVal, wordModel)
        truth = [kwVal[0]['senses']]
        accuracy = p2.accuracyMetrics(predList, truth)
        accDict[i] = accuracy
        if accuracy >= bestAcc :
            bestAcc = accuracy
            bestWin = i
        print linebreak3
        print "Truth is " + str(truth)
        print linebreak2
        print "Accuracy = " + str(accuracy)
    print linebreak3
    print "Best Accuracy was " + str(bestAcc) + "% at " + str(bestWin)
    print linebreak3
    windows = []
    accs = []
    for win in accDict:
        windows.append(win)
        accs.append(accDict[win])
    pl.plot(windows,accs)
    pl.ylim(0,100)
    pl.xlim(1, maxWin)
    pl.show()
    answer = raw_input("Would you like to try a random sampling evaluation?\n")
    if answer.lower() == 'y':
        randomSampleOneWord(kw)
    else:
        trainOneWord()

def randomSampleOneWord(kw):
    maxWin = int(raw_input("What should the maximum window size be?\n"))
    samplingRounds = int(raw_input("How many times should we sample and test?\n"))
    percentTrain = int(raw_input("What percent of the training data should be used for training as opposed to validation?"))*.01
    bestAcc = 0
    bestWin = maxWin+1
    accDict = {}
    total = len(kw)
    numTrain = int(total * percentTrain)
    numVal = int(total - numTrain)
    print linebreak3
    print "Total is " + str(total)
    print "Training set is " + str(numTrain)
    print "Validation set is " + str(numVal)
    for win in range(maxWin, 0, -1):
        #kwTrain = wordData[word][:-1]
        #kwVal = [wordData[word][-1]]
        accList = [] #store accuracy results

        #cross validate with random sampling
        for k in range(0, 3):
            trains = []
            vals = []
            truth = []
            for tr in range(0, numTrain):
                trains.append(rand.choice(kw))
            for v in range(0, numVal):
                vals.append(rand.choice(kw))
            for v in vals:
                truth.append(v['senses'])
            wordModel = p2.buildWordModels(trains, win)
            predList = p2.testFromDict(vals, wordModel)
            accuracy = p2.accuracyMetrics(predList, truth)
            accList.append(accuracy)
        meanAcc = np.mean(accList)
        accDict[win] = meanAcc
        if meanAcc >= bestAcc :
            bestAcc = meanAcc
            bestWin = win
    print linebreak3
    print "Best Accuracy was " + str(bestAcc) + "% at " + str(bestWin)
    if meanAcc >= bestAcc :
        bestAcc = meanAcc
        bestWin = win
        print linebreak3
    windows = []
    accs = []
    for win in accDict:
        windows.append(win)
        accs.append(accDict[win])
    pl.plot(windows,accs)
    pl.ylim(0,100)
    pl.xlim(1, maxWin)
    pl.show()
    randomSampleOneWord(kw)


def act4():
    print linebreak3
    print "Welcome to Naive Bayes Disambiguation: "
    file_loc=raw_input("What file would you like to train on? Type in the path and press ENTER\n")
    wordData=p2.parse(file_loc)
    wordWins=p2.betterTrain(wordData[1], 15)
    print "Better Train Finished"
    print "Making New Word Models"
    print "length of wordData[0] is " + str(len(wordData[0]))
    wordModels=p2.buildWordModelsDict(wordData[0], wordWins)
    print "length of wordModels is " + str(len(wordModels))
    print linebreak2
    print "Model Trained"
    print linebreak2
    test_loc=raw_input("Please input the test file location and press ENTER\n")
    testData=p2.parse(test_loc)
    senseList=p2.testFromDict(testData[0], wordModels)
    #print senseList
    p2.outputSenseList(senseList)


if __name__ == '__main__':
    
    print linebreak1
    print "Welcome to our NLP Project 2"
    print linebreak1

    activity = 0
    while (activity is not 1) and (activity is not 2) and (activity is not 3):
        print "Please select an activity"
        print "1. Dictionary Based Disambiguation"
        print "2. Supervised Disambiguation"
        print "3. Extension : Analyze change in Window Size for One Word"
        print "4. Supervised with Optimized Window Size With A Side Of Fries"
        activity = int(raw_input("Type 1, 2, or 3 and press ENTER\n"))
        if activity == 1:
            act1()
        elif activity == 2:
            act2()
        elif activity== 3:
            trainOneWord()
        elif activity== 4:
            act4()

