'''
Created on Mar 3, 2013

@author: Graham Harwood
'''
import nltk
import nltk.tokenize 
import operator
class wordModel(object):
    
    def __init__(self, word, windowSize):
        self.word=word
        self.windowSize=windowSize
        self.occurs=0 #times this word is seen
        self.senses=dict() #senses for this word key: index of sense value: number of times this sense is seen
        self.contextSense=dict()
        self.senseProbs=dict()
    
    #A way of incrementing the occurs instance field. May be deprecated due to later design decisions
    def occured(self):
        self.occurs+=1
    
    def setWindowSize(self, newSize):
        self.windowSize=newSize
    
    #Mildly fills 
    def setSenses(self, numSenses):
        self.senses=self.dictForSenses(numSenses)
    
    def dictForSenses(self, numSenses):
        senses=dict()
        if not len(dict.keys() > 0):
            for x in range(0, numSenses):
                senses[x]=0;
        return senses
        
        
    def increContextSense(self, sense, context):
        for c in context:
            if c in self.contextSense[sense]:
                self.contextSense[sense][c]+=1
            else:
                self.contextSense[sense][c]=1
    
    def contextStringToTokensOnWindow(self, contextString):
        tokens=nltk.tokenize(contextString)
        counter=0
        context=[]
        for x in tokens:
            if x is self.word:
                wordIndex=counter
                break
            counter+=1
        if wordIndex-self.windowSize>=0 & self.windowSize+wordIndex<=len(tokens):
            for y in range(wordIndex-self.windowSize, wordIndex+self.windowSize):
                if y<wordIndex:
                    context[y]=tokens[y]
                if y>wordIndex:
                    context[y-1]=tokens[y]
        return context
                
    def setSenseProb(self):
        for x in range(0, len(self.senses)-1):
            self.senseProbs[x]=self.senses[x]/self.occurs
    
    def bayesProb(self, ukContext):
        context=self.contextStringToTokensOnWindow(ukContext)
        sProbs=self.dictForSenses(len(self.senses))
        for j in context:
            for k in self.senses:
                if j in self.contextSense[k]:
                    jProb=(self.contextSense[k][j]/self.senses[k])*self.senseProbs[k]
                    if sProbs[k] is 0:
                        sProbs[k]=self.senseProbs
                    else:
                        sProbs[k]=sProbs[k]*jProb
        return sProbs
    
    def senseDecider(self, sProbs):
        mProb=max(sProbs.iteritems(), key=operator.itemgetter(1))[0]
        recSenses=list()
        counter=0
        for x in sProbs:
            if x>(.9*mProb):
                recSenses[counter]=1
            else:
                recSenses[counter]=0
        return recSenses        
            
            
        