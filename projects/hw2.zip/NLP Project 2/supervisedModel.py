'''
Created on Mar 9, 2013

@author: Graham Harwood
'''
'''
Created on Mar 3, 2013

@author: Graham Harwood
'''
import nltk
import nltk.tokenize 
import operator
from nltk.corpus import stopwords
class wordModel(object):
    
    def __init__(self, word, windowSize):
        self.word=word
        self.windowSize=windowSize
        self.occurs=0.0 #times this word is seen
        self.senses=dict() #senses for this word key: index of sense value: number of times this sense is seen
        self.contextSense=dict()
        self.senseProbs=dict()
        self.barMultiplier=.9
    
    #A way of incrementing the occurs instance field. May be deprecated due to later design decisions
    def occured(self):
        self.occurs+=1
    
    def setWindowSize(self, newSize):
        self.windowSize=newSize
    
    #Mildly fills 
    def setSenses(self, numSenses):
        self.senses=self.dictForSenses(numSenses)
        
    def dictForSenses(self, numsenses):
        senses=dict()
        for x in range(0, numsenses):
            senses[x]=0
        return senses
    
    def buildContextSenses(self):
        for x in range(0, len(self.senses)):
            self.contextSense[x]=dict()
    
    def increContextSense(self, sense, fVector):
        for c in fVector:
            if c in self.contextSense[sense]:
                self.contextSense[sense][c]+=1
            else:
                self.contextSense[sense][c]=1
    
    def contextStringToTokensOnWindow(self, contextString):
        #tokens=nltk.word_tokenize(contextString)
        sents = nltk.sent_tokenize(contextString)
        tokens = []
        for s in sents:
            if "@" in s:
                tokens = nltk.word_tokenize(s)

        #tokens = [w for w in tokens if not w in stopwords.words('english')]
        context=list()
        flag=0
        wordIndex=tokens.index('@')
        tokens.remove('@')
        tokens.remove('@')
        if (self.windowSize * 2) >= len(tokens):
            self.windowSize = len(tokens) - 1  
        if wordIndex-self.windowSize>=0 and self.windowSize+wordIndex<=(len(tokens)-1):
            context=tokens[(wordIndex-self.windowSize): wordIndex]+tokens[wordIndex+1:wordIndex +self.windowSize+1]    
        elif wordIndex-self.windowSize<0:
            adjustment=abs(wordIndex-self.windowSize)
            context=tokens[(wordIndex-self.windowSize+adjustment): wordIndex]+tokens[wordIndex+1:wordIndex +self.windowSize+1+adjustment]
        elif wordIndex+self.windowSize>(len(tokens)-1) :
            adjustment=abs((len(tokens)-1)-(wordIndex+self.windowSize))
            context=tokens[(wordIndex-(self.windowSize+adjustment)): wordIndex]+tokens[wordIndex+1:wordIndex +self.windowSize+1-adjustment]

            
            
        return context
                
    def setSenseProb(self):
        for x in range(0, len(self.senses)):
            self.senseProbs[x]=(float(self.senses[x])/float(self.occurs))
    
    def bayesProb(self, ukContext):
        fVector=self.contextStringToTokensOnWindow(ukContext)
        sProbs=dict()
        for j in fVector:
            for k in self.senses:
                if j in self.contextSense[k]:
                    jProb=(float(self.contextSense[k][j])/float(self.senses[k]))*float(self.senseProbs[k])
                if k not in sProbs and k in self.senseProbs:
                    sProbs[k]=self.senseProbs[k]*self.senseProbs[k]
                elif j in self.contextSense[k]:
                    sProbs[k]=float(sProbs[k])*jProb
        return sProbs
    
    def senseDecider(self, sProbs):
        mProb=0.0
        flag=0
        for y in sProbs:
            if sProbs[y]>mProb:
                mProb=sProbs[y]
        recSenses=list()
        if mProb is 0:
            print "mProb is still 0"
        for x in sProbs:
            if sProbs[x]>(self.barMultiplier*mProb):
                recSenses.append(1)
            else:
                recSenses.append(0)
        for x in sProbs:
            if sProbs[x] is not 0 or 0.0:
                flag=1
        #if flag is 0:
            #recSenses[0]=1
        return recSenses        
            
            
        