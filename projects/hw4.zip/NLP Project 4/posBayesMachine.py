'''
Created on Apr 23, 2013

@author: graham
'''
'''
Created on Apr 21, 2013

@author: Graham Harwood
'''
'''
Created on Mar 3, 2013

@author: Graham Harwood
'''
import nltk
import nltk.tokenize 
import operator
from nltk.corpus import stopwords
class posBayesMachine(object):
    
    def __init__(self):
        self.wordCounts=dict()
        self.decWordCounts=dict()
        self.decCount={'1':0,'0':0}
        self.decProbs={'1':0.0,'0':0.0}
        
        
    def setFromReviews(self, reviews):
        self.wordCounts=dict()
        self.decWordCounts['0']=dict()
        self.decWordCounts['1']=dict()
        for x in reviews:
            self.decCount[x['isTrue']]+=1
            for y in x['posTags']:
                if y[1] in self.wordCounts:
                    self.wordCounts[y[1]]+=1
                    if y[1] in self.decWordCounts[x['isTrue']]:
                        self.decWordCounts[x['isTrue']][y[1]]+=1
                    else:
                        self.decWordCounts[x['isTrue']][y[1]]=1
                else:
                    self.wordCounts[y[1]]=1
                    self.decWordCounts[x['isTrue']][y[1]]=1
        print self.decWordCounts
        
    def setDecProbs(self):
        total=self.decCount['0']+self.decProbs['1']
        self.decProbs['0']=float(self.decCount['0'])/float(total)
        self.decProbs['1']=float(self.decCount['1'])/float(total)
        
        
                    
    def bayesProb(self, uTokens):
        dProb=[0.0, 0.0]
        #print self.decCount['0']
        #print self.decCount['1']
    
        for x in uTokens:
            if x in self.decWordCounts['0']:
                dProb[0]+=(float(self.decWordCounts['0'][x])/float(self.decCount['0']))*self.decProbs['0']
            if x in self.decWordCounts['1']:
                dProb[1]+=(float(self.decWordCounts['1'][x])/float(self.decCount['1']))*self.decProbs['1']
        #print '0: ' + str(dProb[0]) + '      1: ' + str(dProb[1])
        if dProb[0]>1.20*dProb[1]:
            return 0
        else:
            return 1
        
        