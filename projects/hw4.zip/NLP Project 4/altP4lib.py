'''
Created on Apr 25, 2013

@author: graham
'''
import nltk
import numpy as np
#import sklearn
import re
import os

def get_data():
    '''
        imports the data file 'Phase 1 Data' which is expected to be in the working directory
        outputs a data structure that is a list in which each cell represents a dictionary
        that contains the following key - value pairs.
            'review' : The actual review text
            'isTrue' : 0 for false, 1 for True
            'auth1' : 0 if auth1 determined it to be false, 1 otherwise
            'auth2' : see 'auth1'
            'auth3' : see 'auth1'
            'tokens' : the tokenized list of words in the review
            'posTags' : a list of tuples where the first index of each tuple represents
                        the word, and the second index represents the part of speech tag
            'posFreq' : This is the frequency distribution for each part of speech tag
    '''
    data = open("Train data", "r").readlines()
    dataDicts = []
    numPNTrue = 0
    numPNFalse = 0
    for d in range(1, len(data)):
        dataDict=dict()
        dataDict['tokens'] = nltk.word_tokenize(data[d])
        splitup=dataDict['tokens'][0]
        dataDict['isTrue'] = splitup[0]
        #print dataDict['isTrue']
        dataDict['isPosit']= splitup[2]
        dataDict['posTags'] = nltk.pos_tag(dataDict['tokens'])
        tag_fd = nltk.FreqDist(tag for (word, tag) in dataDict['posTags'])
        dataDict['posFreq'] = tag_fd
        dataDicts.append(dataDict)
        
    return dataDicts

def get_dataTest():
    '''
        imports the data file 'Phase 1 Data' which is expected to be in the working directory
        outputs a data structure that is a list in which each cell represents a dictionary
        that contains the following key - value pairs.
            'review' : The actual review text
            'isTrue' : 0 for false, 1 for True
            'auth1' : 0 if auth1 determined it to be false, 1 otherwise
            'auth2' : see 'auth1'
            'auth3' : see 'auth1'
            'tokens' : the tokenized list of words in the review
            'posTags' : a list of tuples where the first index of each tuple represents
                        the word, and the second index represents the part of speech tag
            'posFreq' : This is the frequency distribution for each part of speech tag
    '''
    data = open("Test data", "r").readlines()
    dataDicts = []
    numPNTrue = 0
    numPNFalse = 0
    for d in range(1, len(data)):
        dataDict=dict()
        dataDict['tokens'] = nltk.word_tokenize(data[d])
        dataDict['isTrue'] = dataDict['tokens'][0]
        dataDict['isPosit']= dataDict['tokens'][3]
        #dataDict['auth1'] = dataSplit[-3]
        #dataDict['auth2'] = dataSplit[-2]
        #dataDict['auth3'] = dataSplit[-1]
        dataDict['posTags'] = nltk.pos_tag(dataDict['tokens'])
        tag_fd = nltk.FreqDist(tag for (word, tag) in dataDict['posTags'])
        dataDict['posFreq'] = tag_fd
        dataDicts.append(dataDict)
        
    return dataDicts
    
def get_lengths(rev_data):
    '''
        input : takes in data structure from get_data()
        output : a list where each cell represents the length of a review.
                list will be in the same order as rev_data
    '''
    lengths = []
    for rev in rev_data:
        lengths.append(len(rev['review']))

    return lengths

def get_proper_nouns(rev_data):
    '''
        input : takes in data structure from get_data()
        output : a list where each cell represents the number of proper nouns
                in a particular review.  list will be in same order as rev_data
    '''
    pNouns = []
    for rev in rev_data:
        pNouns.append(rev['posFreq']['NNP'] + rev['posFreq']['NNPS'])

    return pNouns

def get_max_freq(rev_data):
    '''
        input: takes in data structure from get_data()
        output: a list where each cell represents the frequency of the most frequent word
                in the review, not including stop words.  

                Could be more robust later, by
                coming up with a list of uncommon words and the amount that they appear
                for a particular review.
    '''
    max_freq = []
    print "importing stop words"
    stopwords = nltk.corpus.stopwords.words('english')

    for rev in rev_data:
        content = [w for w in rev['tokens'] if w.lower() not in stopwords]
        freqs = nltk.FreqDist(content)
        max_freq.append(freqs[freqs.max()])

    return max_freq

def get_superlatives(rev_data):
    '''
        input: takes in data structure from get_data()
        output: a list where each cell represents the number of superlatives in a review.
                list is in the same order as rev_data()
    '''
    superlatives = []
    for rev in rev_data:
        superlatives.append(rev['posFreq']['JJS'] + rev['posFreq']['RBS'])
    return superlatives

def get_repeated_exPoints(rev_data):
    '''
        input: takes in data structure from get_data()
        output: a list where each cell represents the amount of times that
                consecutive !'s occur
    '''
    rep_exPoints = []
    for rev in rev_data:
        exPoints = re.findall(r'\!+\!+', rev['review'])
        rep_exPoints.append(len(exPoints))
    return rep_exPoints



def outputToFile(testBase, filename):
    if os.path.exists(filename):
        os.remove(filename)
    output=open(filename, "a")
    for x in range(0, len(testBase)):
        for y in range(0, len(testBase[x])):
            output.write(testBase[x][y][1] + "\n")


