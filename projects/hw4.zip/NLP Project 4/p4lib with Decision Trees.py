import nltk
import numpy as np
from sklearn import svm, preprocessing, tree
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
import re
import sys
import pickle
from sklearn.feature_selection import SelectKBest, chi2

lb1 = "--------------------------------"
altPosWords = open('altPosWords.txt', 'r').readlines()
altNegWords = open('altNegWords.txt', 'r').readlines()
negWords = open('negativeWords.txt','r').readlines()
posWords = open('positiveWords.txt','r').readlines()
posWordsD=dict()
negWordsD=dict()
for pos in range(0,len(posWords)):
	posWords[pos]=posWords[pos].strip()
	posWordsD[posWords[pos]]=0
for neg in range(0, len(negWords)):
	negWords[neg]=negWords[neg].strip()
	negWordsD[negWords[neg]]=0
for p in range(0, len(altPosWords)):
	altPosWords[p]=altPosWords[p].strip()
	altPosWords[p]=altPosWords[p].upper()
	posWordsD[altPosWords[pos]]=0
for n in range(0, len(altNegWords)):
	altNegWords[n]=altNegWords[n].strip()
	altNegWords[n]=altNegWords[n].upper()
	negWordsD[altNegWords[neg]]=0
conjAdv= ['however,', 'however', 'but', 'yet', 'though']

spaWords = ['spa','massage','massaged','spa-like','spas','sauna','saunas','relax','relaxation','relaxing','relaxes']
familyWords = ['husband','wife','sister','brother','cousin','family','uncle','aunt','grandmother','grandma','grandfather','grandpa','mother','father','mom','dad']
luxuryWords = ['luxury','luxurious','luxuriousness','luxuriant','indulgence','indulge','indulgent','indulgently','bliss','blissful','sumptuous','sumptuousness','splendor','splendors','splendid','splendidly','extravagant','extravagance','extravagantly']
weddingWords = ['wedding','weddings','wed','fiance','fiancee','bride','groom','bridesmaid','bridesmaids','marriage','marry','anniversary','honeymoon']
vacationWords = ['vacation','vacationing','vacations','holiday','weekend','getaway','retreat','recreation','leisure','leisurely']
businessWords = ['business','businesses','conference','conferences','meeting','meetings']
comfortWords = ['comfortable','comfort','comfortably','content','contented','contentedly']
convenienceWords = ['convenient','conveniently','convenience']

leafSize = 25
num_estimators = 1000

def get_pickeled_data():
	return pickle.load(open("train_val_test.pkl", "rb"))

def set_most_common(rev_data):
	corpus = []
	for rev in rev_data:
		corpus += rev['tokens']

	fdCorpus = nltk.FreqDist(corpus)
	return fdCorpus

def get_data():
	'''
		imports the data file 'Phase 1 Data' which is expected to be in the working directory
		outputs a data structure that is a list in which each cell represents a dictionary
		that contains the following key - value pairs.
			'review' : The actual review text
			'isTrue' : 0 for false, 1 for True
			'auth1' : 0 if auth1 determined it to be false, 1 otherwise
			'auth2' : see 'auth1'
			'auth3' : see 'auth1'
			'tokens' : the tokenized list of words in the review
			'posTags' : a list of tuples where the first index of each tuple represents
						the word, and the second index represents the part of speech tag
			'posFreq' : This is the frequency distribution for each part of speech tag
	'''

	data = open("Phase 1 Data", "r").readlines()

	dataDicts = []
	numPNTrue = 0
	numPNFalse = 0
	for d in range(1, len(data)):
		lquote = data[d].find('"')
		rquote = data[d].rfind('"')
		dataDict = {'review' : data[d][lquote+1:rquote]}
		dataSplit = data[d].split(";")
		dataDict['isTrue'] = dataSplit[0]
		dataDict['auth1'] = dataSplit[-3]
		dataDict['auth2'] = dataSplit[-2]
		dataDict['auth3'] = dataSplit[-1]
		dataDict['tokens'] = nltk.word_tokenize(dataDict['review'])
		dataDict['posTags'] = nltk.pos_tag(dataDict['tokens'])
		tag_fd = nltk.FreqDist(tag for (word, tag) in dataDict['posTags'])
		dataDict['posFreq'] = tag_fd
		dataDicts.append(dataDict)
		
	return dataDicts

def clean_data(string):
	'''
		input: takes in string
		output: cleaner string
	'''
	newString = string.strip()
	newString = newString.replace('\xc2\xc99', '')
	newString = newString.replace('\x92', "\'")
	newString = newString.replace('\x96', '-')
	newString = newString.replace('\x85', '...')
	newString = newString.replace('\xe2\x80\x99', "\'")
	newString = newString.replace(';', ',')
	return newString.split(",")

def get_data2():
	'''
		imports the data file 'Phase 1 Data' which is expected to be in the working directory
		outputs a data structure that is a list in which each cell represents a dictionary
		that contains the following key - value pairs.
			'review' : The actual review text
			'isTrue' : 0 for false, 1 for True
			'isPositive' : 0 if negative review, 1 if positive
			'tokens' : the tokenized list of words in the review
			'posTags' : a list of tuples where the first index of each tuple represents
						the word, and the second index represents the part of speech tag
			'posFreq' : This is the frequency distribution for each part of speech tag
	'''

	train = open('Train data', "r").readlines()
	val = open('Validation data').readlines()

	trainDicts = []
	valDicts = []
	numPNTrue = 0
	numPNFalse = 0
	for d in range(1, len(train)):
		try:
			data = clean_data(train[d])
			review = ','.join(data[2:])
			dataDict = {'review' : review}
			dataDict['isTrue'] = data[0]
			dataDict['isPositive'] = data[1]
			dataDict['tokens'] = nltk.word_tokenize(dataDict['review'])
			dataDict['posTags'] = nltk.pos_tag(dataDict['tokens'])
			tag_fd = nltk.FreqDist(tag for (word, tag) in dataDict['posTags'])
			dataDict['posFreq'] = tag_fd
			trainDicts.append(dataDict)
		except TypeError:
			print "Review " + str(d) + " was the problem"
			print repr(train[d])
			raw_input('press any key')

	for d in range(1, len(val)):
		data = clean_data(val[d])
		review = ','.join(data[2:])
		dataDict = {'review' : review}
		dataDict['isTrue'] = data[0]
		dataDict['isPositive'] = data[1]
		dataDict['tokens'] = nltk.word_tokenize(dataDict['review'])
		dataDict['posTags'] = nltk.pos_tag(dataDict['tokens'])
		tag_fd = nltk.FreqDist(tag for (word, tag) in dataDict['posTags'])
		dataDict['posFreq'] = tag_fd
		valDicts.append(dataDict)		
		
	return trainDicts, valDicts

def get_testData():
	test = open('Test data', "r").readlines()
	testDicts = []
	for d in range(1, len(test)):
		data = clean_data(test[d])
		review = ','.join(data[2:])
		dataDict = {'review' : review}
		dataDict['isTrue'] = data[0]
		dataDict['isPositive'] = data[1]
		dataDict['tokens'] = nltk.word_tokenize(dataDict['review'])
		dataDict['posTags'] = nltk.pos_tag(dataDict['tokens'])
		tag_fd = nltk.FreqDist(tag for (word, tag) in dataDict['posTags'])
		dataDict['posFreq'] = tag_fd
		testDicts.append(dataDict)
	return testDicts

def train_deceptive_words(rev_data):
	'''
		input: takes in data structure from get_data()
		output: a list where each cell represents a number corresponding with
				words that were used in deceptive reviews, but not truthful ones
	'''
	n = 30
	print "Extracting Deceptive Words"
	most_common_deceptive = []
	most_common_truthful = []
	deception_scores = []
	true_corpus = []
	false_corpus = []
	for rev in rev_data:
		if rev['isTrue'] is '1':
			true_corpus += rev['tokens']
		else:
			false_corpus += rev['tokens']

	true_fd = nltk.FreqDist(true_corpus)
	false_fd = nltk.FreqDist(false_corpus)
	true_words = true_fd.keys()
	false_words = false_fd.keys()
	unique = False
	runs = 0
	while not unique:
		print "run " + str(runs)
		runs += 1
		#print str(len(true_words))
		most_common_truthful = true_words[:n]
		most_common_deceptive = false_words[:n]
		bools = []
		for d in most_common_deceptive:
			#print "word is " + d
			if d in most_common_truthful:
				true_words.remove(d)
				false_words.remove(d)
				bools.append(False)
			else:
				bools.append(True)
		if False not in bools:
			unique = True

	print lb1
	print most_common_deceptive
	print most_common_truthful
	print lb1
	return {'deceptive' : most_common_deceptive, 'truthful' : most_common_truthful}

def get_deceptive_words(train, test):
	words = train_deceptive_words(train)
	deceptive = 0.
	truthful = 0.
	scores = []
	for rev in train:
		count = 0
		for word in rev['tokens']:
			if word in words['deceptive']:
				deceptive+=1.
			elif word in words['truthful']:
				truthful+=1.
		scores.append(float(deceptive)/float(truthful))

	return scores

def get_lengths(rev_data):
	'''
		input : takes in data structure from get_data()
		output : a list where each cell represents the length of a review.
				list will be in the same order as rev_data
	'''
	print "Extracting sentence length by characters"
	lengths = []
	for rev in rev_data:
		lengths.append(len(rev['review']))

	return lengths

def get_lengths_token(rev_data):
	'''
		input : takes in data structure from get_data()
		output : a list where each cell represents the number of tokens in a review.
				list will be in the same order as rev_data
	'''
	lengths = []
	for rev in rev_data:
		lengths.append(len(rev['tokens']))
		
	return lengths

def get_num_char(rev_data,char):
	'''
		input : takes in data structure from get_data(), and a character
		output : a list where each cell represents the number of times the character occurs in the review.
				list will be in the same order as rev_data
	'''
	print "Extracting number of " + str(char)
	output = []
	for rev in rev_data:
		output.append(rev['review'].count(char))
	return output

def get_proper_nouns(rev_data):
	'''
		input : takes in data structure from get_data()
		output : a list where each cell represents the number of proper nouns
				in a particular review.  list will be in same order as rev_data
	'''
	print "Extracting number of proper nouns"
	pNouns = []
	for rev in rev_data:
		pNouns.append(rev['posFreq']['NNP']) #+ rev['posFreq']['NNPS'])

	return pNouns

def get_max_freq(rev_data):
	'''
		input: takes in data structure from get_data()
		output: a list where each cell represents the frequency of the most frequent word
				in the review, not including stop words.  

				Could be more robust later, by
				coming up with a list of uncommon words and the amount that they appear
				for a particular review.
	'''
	print "Extracting frequency of most frequent word"
	max_freq = []
	#print "importing stop words"
	stopwords = nltk.corpus.stopwords.words('english')

	for rev in rev_data:
		content = [w for w in rev['tokens'] if w.lower() not in stopwords]
		freqs = nltk.FreqDist(content)
		max_freq.append(freqs[freqs.max()])

	return max_freq

def get_max_freq2(rev_data, n):
	'''
		input:
			takes in data structure from get_data() as rev_data and n where n is an integer
			representing how many most common features to consider
		output:
			a list where each cell represents the frequency of the most frequent
			adjective or adverb, that is not in the n-most common words of the training
			data
	'''
	print "Extracting frequency of rare adjectives and adverbs"
	stopwords = nltk.corpus.stopwords.words('english')
	fdCorpus = set_most_common(rev_data)
	print fdCorpus.keys()[:n]
	maxFreq = 0
	maxFreqList = []
	i = 0
	for rev in rev_data:
		maxFreq = 0
		print "Processing Review " + str(i)
		i+=1
		for pos in rev['posTags']:
			if (pos[0] not in fdCorpus.keys()[:n]) and (('JJ' in pos[1]) or ('RB' in pos[1])):
				maxFreq += 1
				
		#print "MaxFreq : " + str(maxFreq)
		maxFreqList.append(maxFreq)
		#if (len(maxFreqList) > 0):
			#print maxFreqList
	return maxFreqList

def get_superlatives(rev_data):
	'''
		input: takes in data structure from get_data()
		output: a list where each cell represents the number of superlatives in a review.
				list is in the same order as rev_data()
	'''
	print "Extracting number of superlatives"
	superlatives = []
	for rev in rev_data:
		superlatives.append(rev['posFreq']['JJS'] + rev['posFreq']['RBS'])
	return superlatives

def get_repeated_exPoints(rev_data):
	'''
		input: takes in data structure from get_data()
		output: a list where each cell represents the amount of times that
				consecutive !'s occur
	'''
	print "Extracting number of consecutive exclamation points"
	rep_exPoints = []
	for rev in rev_data:
		exPoints = re.findall(r'\!+\!+', rev['review'])
		rep_exPoints.append(len(exPoints))
	return rep_exPoints

def get_posFreqs(rev_data, pos):
	print "Extracting frequency of " + pos
	posNums = []
	for rev in rev_data:
		posNums.append(rev['posFreq'][pos])
	return posNums

def get_posFreqsList(rev_data, posList):
	posWords = ', '.join(posList)
	print "Extracting Counts of " + posWords
	posNums = []
	for rev in rev_data:
		nums = 0
		for p in posList:
			nums += rev['posFreq'][p]
		posNums.append(nums)
	return posNums

def get_truthful(rev_data):
	'''
		input: takes in data structure from get_data()
		output: a list where each cell refers to whether or not the corresponding
				review was truthful.
	'''
	print "Extracting labels"
	truths = []
	for rev in rev_data:
		truths.append(int(rev['isTrue']))
	return truths

###### New Stuff added Saturday Morning ####

def get_discreteWords(rev_data):
    print 'Extracting number of discrete words feature'
    featList=list()
    for r in rev_data:
        seen=list()
        counter=0
        for x in r['tokens']:
            if x not in seen:
                counter+=1
            else:
                seen.append(x)
        featList.append(counter)
    return featList

def get_ratioPosNeg(rev_data):
	print 'Extracting Ratio of Positive Negative Words'
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		pCounter=0
		for x in tokens: 
			if x.upper() in posWordsD:
				pCounter+=1
			elif x.upper() in negWordsD:
				nCounter+=1
		if nCounter is not 0:
			featList.append(float(pCounter)/float(nCounter))
		else:
			featList.append(float(pCounter))
	return featList

def get_numNegWords(rev_data):
	print 'Extracting Negative Words'
	featList=list()
	for rev in rev_data:
		tokens=rev['tokens']
		nCounter=0
		for x in tokens:
			x=x.upper()
			xMin=x[0:len(x)-1]
			if x in negWordsD or xMin in negWordsD:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_numPosWords(rev_data):
	print 'Extracting Positive Words'
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			x=x.upper()
			xMin=x[0:len(x)-1]
			if x in posWordsD or xMin in posWordsD :
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_conjAdverbs(rev_data):
	print 'Extracting Conjunctive Adverbs'
	featList=list()
	sList=get_sentiment(rev_data)
	for r in range(0, len(rev_data)):
		tokens=rev_data[r]['tokens']
		nCounter=0
		for x in tokens:
			if x in conjAdv:
				nCounter+=1
		if sList[r] == '1' and nCounter != 0:
			nCounter=nCounter*-1.0
			
		featList.append(float(nCounter))
	return featList

def get_sentiment(rev_data):
	print 'Extracting Predicted Sentiments'
	pList=get_numPosWords(rev_data)
	nList=get_numNegWords(rev_data)
	guessList=list()
	sumList=list()
	for y in range(0, len(pList)):
		sumList.append(pList[y]-nList[y])
	sAvg=np.average(sumList)
	print sAvg
	for z in range(0, len(sumList)):
		if sumList[z]>(sAvg-1.0):
			guessList.append('1')
		else:
			guessList.append('0')	
	return guessList

def get_ellipsis(rev_data):
	print 'Extracting Ellipsis'
	
	output = []
	for rev in rev_data:
		output.append(rev['review'].lower().count("..."))
	return output	

def get_spa(rev_data):
	print 'Extracting Spa Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in spaWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_family(rev_data):
	print 'Extracting Family Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in familyWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_luxury(rev_data):
	print 'Extracting Luxury Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in luxuryWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_wedding(rev_data):
	print 'Extracting Wedding Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in weddingWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_vacation(rev_data):
	print 'Extracting Vacation Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in vacationWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_business(rev_data):
	print 'Extracting Business Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in businessWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_comfort(rev_data):
	print 'Extracting Comfort Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in comfortWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList

def get_convenience(rev_data):
	print 'Extracting Convenience Words'
	
	featList=list()
	for r in rev_data:
		tokens=r['tokens']
		nCounter=0
		for x in tokens:
			if x in convenienceWords:
				nCounter+=1
		featList.append(float(nCounter))
	return featList	

####   MAIN METHODS ####

def get_features(rev_data):
	'''
		input: takes in data structure from get_data()
		output: a tuple where [0] is the a numpy array with features across the rows
				and samples across the columns and [1] is a list of labels
	'''
	labels = get_truthful(rev_data)
	lengths = get_lengths(rev_data)
	lengths_token = get_lengths_token(rev_data)
	pNouns = get_proper_nouns(rev_data)
	maxFreqs = get_max_freq(rev_data)
	#dec_words = get_deceptive_words(rev_data)
	#maxFreqs2 = get_max_freq2(rev_data, 200)
	superLs = get_superlatives(rev_data)
	exPoints = get_repeated_exPoints(rev_data)
	commas = get_num_char(rev_data,',')
	qtns = get_num_char(rev_data,'?')
	periods = get_num_char(rev_data,'.')
	excls = get_num_char(rev_data,'!')
	dollars = get_num_char(rev_data,'$')
	semis = get_num_char(rev_data,';')
	adjs = get_posFreqsList(rev_data, ['JJ', 'JJR', 'JJS'])
	#compadjs = get_posFreqs(rev_data, 'JJR')
	#superLadjs = get_posFreqs(rev_data, 'JJS')
	adverbs = get_posFreqsList(rev_data, ['RB', 'RBR', 'RBS'])
	det = get_posFreqs(rev_data, 'DT')
	pDet = get_posFreqs(rev_data, 'PDT')
	verbs = get_posFreqsList(rev_data, ['VB', 'VBD', 'VBG', 'VBN','VBP', 'VBZ'])
	#print "verbs"
	#print verbs

	#Jennifer's new additions
	ellipsis = get_ellipsis(rev_data)
	spa = get_spa(rev_data)
	family = get_family(rev_data)
	luxury = get_luxury(rev_data)
	wedding = get_wedding(rev_data)
	vacation = get_vacation(rev_data)
	business = get_business(rev_data)
	comfort = get_comfort(rev_data)
	convenience = get_convenience(rev_data)

	#Graham's New additions
	discWords = get_discreteWords(rev_data)
	ratio = get_ratioPosNeg(rev_data)
	Negs = get_numNegWords(rev_data)
	Pos = get_numPosWords(rev_data)
	conjadv = get_conjAdverbs(rev_data)
	sentiment = get_sentiment(rev_data)
	
	if (len(rev_data) == len(lengths) == len(lengths_token) == len(pNouns) == len(maxFreqs)
		== len(superLs) == len(exPoints) == len(labels) == len(commas) == len(qtns)
		== len(periods) == len(excls) == len(dollars) == len(semis)):
		
		features = []
		for i in range(0, len(rev_data)):
			featureVec = []
			featureVec.append(np.float64(lengths[i])) #0
			featureVec.append(np.float64(lengths_token[i])) #1
			featureVec.append(np.float64(pNouns[i])) #2
			featureVec.append(np.float64(maxFreqs[i])) #3
			featureVec.append(np.float64(det[i])) #4
			featureVec.append(np.float64(pDet[i])) #5
			featureVec.append(np.float64(verbs[i])) #6
			featureVec.append(np.float64(adverbs[i])) #7
			#featureVec.append(np.float64(maxFreqs2[i]))
			featureVec.append(np.float64(superLs[i])) #8
			featureVec.append(np.float64(exPoints[i])) #9
			featureVec.append(np.float64(adjs[i])) #10
			#featureVec.append(np.float64(compadjs[i]))
			#featureVec.append(np.float64(superLadjs[i]))
			featureVec.append(np.float64(commas[i])) #11
			featureVec.append(np.float64(qtns[i])) #12
			featureVec.append(np.float64(periods[i])) #13
			featureVec.append(np.float64(excls[i])) #14
			featureVec.append(np.float64(dollars[i])) #15
			featureVec.append(np.float64(semis[i]))#16
			#featureVec.append(np.float64(dec_words[i]))
			featureVec.append(np.float64(ellipsis[i])) #17
			featureVec.append(np.float64(spa[i])) #18
			featureVec.append(np.float64(family[i])) #19
			featureVec.append(np.float64(luxury[i])) #20
			featureVec.append(np.float64(wedding[i])) #21
			featureVec.append(np.float64(vacation[i])) #22
			featureVec.append(np.float64(business[i])) #23
			featureVec.append(np.float64(comfort[i])) #24
			featureVec.append(np.float64(convenience[i])) #25
			featureVec.append(np.float64(discWords[i])) #26
			featureVec.append(np.float64(ratio[i]))#27
			featureVec.append(np.float64(Negs[i]))#28
			featureVec.append(np.float64(Pos[i]))#29
			featureVec.append(np.float64(conjadv[i]))#30
			featureVec.append(np.float64(sentiment[i]))#31
			
			features.append(featureVec)
		featArr = np.array(features)
		return featArr, labels
	else:
		raise ValueError('Feature Vectors did not end up as being equal length')

def get_test_features(rev_data):
	'''
		input: takes in data structure from get_data()
		output: a tuple where [0] is the a numpy array with features across the rows
				and samples across the columns and [1] is a list of labels
	'''
	lengths = get_lengths(rev_data)
	lengths_token = get_lengths_token(rev_data)
	pNouns = get_proper_nouns(rev_data)
	maxFreqs = get_max_freq(rev_data)
	#dec_words = get_deceptive_words(rev_data)
	#maxFreqs2 = get_max_freq2(rev_data, 200)
	superLs = get_superlatives(rev_data)
	exPoints = get_repeated_exPoints(rev_data)
	commas = get_num_char(rev_data,',')
	qtns = get_num_char(rev_data,'?')
	periods = get_num_char(rev_data,'.')
	excls = get_num_char(rev_data,'!')
	dollars = get_num_char(rev_data,'$')
	semis = get_num_char(rev_data,';')
	adjs = get_posFreqsList(rev_data, ['JJ', 'JJR', 'JJS'])
	#compadjs = get_posFreqs(rev_data, 'JJR')
	#superLadjs = get_posFreqs(rev_data, 'JJS')
	adverbs = get_posFreqsList(rev_data, ['RB', 'RBR', 'RBS'])
	det = get_posFreqs(rev_data, 'DT')
	pDet = get_posFreqs(rev_data, 'PDT')
	verbs = get_posFreqsList(rev_data, ['VB', 'VBD', 'VBG', 'VBN','VBP', 'VBZ'])
	#print "verbs"
	#print verbs

	#Jennifer's new additions
	ellipsis = get_ellipsis(rev_data)
	spa = get_spa(rev_data)
	family = get_family(rev_data)
	luxury = get_luxury(rev_data)
	wedding = get_wedding(rev_data)
	vacation = get_vacation(rev_data)
	business = get_business(rev_data)
	comfort = get_comfort(rev_data)
	convenience = get_convenience(rev_data)

	#Graham's New additions
	discWords = get_discreteWords(rev_data)
	ratio = get_ratioPosNeg(rev_data)
	Negs = get_numNegWords(rev_data)
	Pos = get_numPosWords(rev_data)
	conjadv = get_conjAdverbs(rev_data)
	sentiment = get_sentiment(rev_data)
	
	if (len(rev_data) == len(lengths) == len(lengths_token) == len(pNouns) == len(maxFreqs)
		== len(superLs) == len(exPoints) == len(commas) == len(qtns)
		== len(periods) == len(excls) == len(dollars) == len(semis)):
		
		features = []
		for i in range(0, len(rev_data)):
			featureVec = []
			featureVec.append(np.float64(lengths[i])) #0
			featureVec.append(np.float64(lengths_token[i])) #1
			featureVec.append(np.float64(pNouns[i])) #2
			featureVec.append(np.float64(maxFreqs[i])) #3
			featureVec.append(np.float64(det[i])) #4
			featureVec.append(np.float64(pDet[i])) #5
			featureVec.append(np.float64(verbs[i])) #6
			featureVec.append(np.float64(adverbs[i])) #7
			#featureVec.append(np.float64(maxFreqs2[i]))
			featureVec.append(np.float64(superLs[i])) #8
			featureVec.append(np.float64(exPoints[i])) #9
			featureVec.append(np.float64(adjs[i])) #10
			#featureVec.append(np.float64(compadjs[i]))
			#featureVec.append(np.float64(superLadjs[i]))
			featureVec.append(np.float64(commas[i])) #11
			featureVec.append(np.float64(qtns[i])) #12
			featureVec.append(np.float64(periods[i])) #13
			featureVec.append(np.float64(excls[i])) #14
			featureVec.append(np.float64(dollars[i])) #15
			featureVec.append(np.float64(semis[i]))#16
			#featureVec.append(np.float64(dec_words[i]))
			featureVec.append(np.float64(ellipsis[i])) #17
			featureVec.append(np.float64(spa[i])) #18
			featureVec.append(np.float64(family[i])) #19
			featureVec.append(np.float64(luxury[i])) #20
			featureVec.append(np.float64(wedding[i])) #21
			featureVec.append(np.float64(vacation[i])) #22
			featureVec.append(np.float64(business[i])) #23
			featureVec.append(np.float64(comfort[i])) #24
			featureVec.append(np.float64(convenience[i])) #25
			featureVec.append(np.float64(discWords[i])) #26
			featureVec.append(np.float64(ratio[i]))#27
			featureVec.append(np.float64(Negs[i]))#28
			featureVec.append(np.float64(Pos[i]))#29
			featureVec.append(np.float64(conjadv[i]))#30
			featureVec.append(np.float64(sentiment[i]))#31
			
			features.append(featureVec)
		featArr = np.array(features)
		return featArr
	else:
		raise ValueError('Feature Vectors did not end up as being equal length')



def accuracy(predictions, truths):
	if (len(predictions) == len(truths)):
		correct = 0.
		total = len(predictions)
		for i in range(0, total):
			if predictions[i] == truths[i]:
				correct += 1.

		return ( correct / total ) * 100.

def standardize(train, vals):
	'''
		input : takes in data structure from get_features()
		output: a tuple where [0] is the standardized training set,
				and [1] is the standardized validation set
	'''
	scaler = preprocessing.StandardScaler().fit(train)
	trainScaled = scaler.transform(train)
	valsScaled = scaler.transform(vals)
	print trainScaled
	print valsScaled
	return trainScaled, valsScaled

def mmStandardize(train,vals):
	'''
		input: takes in data structure fom get_data2()
		output:	the zero mean and unit variance scaled data from 0 to 1
	'''
	mmScaler = preprocessing.MinMaxScaler()
	mmTrain = mmScaler.fit_transform(train)
	mmVals = mmScaler.transform(vals)
	print mmTrain
	print mmVals
	return mmTrain, mmVals

# SVM Methods
def run_svm(rev_data):
	'''
		input : takes input from get_data2()
		output: reports accuracy using SVM
	'''
	train = get_features(rev_data[0])
	vals = get_features(rev_data[1])
	svm_performance(train, vals)
	
def svm_performance(train, vals):
	'''
		input: takes in data structure from get_features()
		output: svm classifier objected that is fitted to the training data
	'''
	# scale training data and validation data
	scaled = mmStandardize(train[0],vals[0])
	trainFeatures = scaled[0]
	trainLabels = train[1]
	valFeatures = scaled[1]
	valLabels = vals[1]

	# select K Best Features using chi-2 scoring
	ch2 = SelectKBest(chi2, k=20)
	trainBest = ch2.fit_transform(trainFeatures, trainLabels)
	valsBest = ch2.transform(valFeatures)
	selected = ch2.get_support()
	for i in range(0,len(selected)):
		if selected[i]:
			print str(i) + " feature was selected"
	clf = svm.LinearSVC()
	clf.fit(trainBest, trainLabels)
	predictions = clf.predict(valsBest)
	acc = accuracy(predictions, valLabels)
	print "Performance : " + str(acc) + "%"

def svm_pred(train, test, kBest):
	scaled = mmStandardize(train[0], test)
	trainFeatures = scaled[0]
	trainLabels = train[1]
	testFeatures = scaled[1]
	# select K Best Features using chi-2 scoring
	ch2 = SelectKBest(chi2, k=kBest)
	trainBest = ch2.fit_transform(trainFeatures, trainLabels)
	valsBest = ch2.transform(testFeatures)
	selected = ch2.get_support()
	for i in range(0,len(selected)):
		if selected[i]:
			print str(i) + " feature was selected"
	clf = svm.LinearSVC()
	clf.fit(trainBest, trainLabels)
	predictions = clf.predict(valsBest)
	return predictions

def run_svmTest(rev_data, testData):
	'''
		input: takes in output from get_data2() and output from get_testData()
		output: outputs a file called determined by the testFile field that is
				ready for Kaggle
	'''
	train = get_features(rev_data[0])
	test = get_test_features(testData)
	print "Test is " + str(len(test))
	scaled = mmStandardize(train[0],test)
	trainScaled = scaled[0]
	testScaled = scaled[1]
	print "Test scaled is " + str(len(testScaled))
	trainLabels = train[1]
	clf = svm.LinearSVC()
	clf.fit(trainScaled, trainLabels)
	predictions = clf.predict(testScaled)
	print "There were " + str(len(predictions)) + " predictions"
	outFile = open(testFile, 'w')
	for i in predictions:
		outFile.write(str(i) + "\n")


# NAIVE BAYES Methods
def run_sklearnNB(rev_data):
	'''
		input : takes input from get_data2()
		output: reports accuracy using sklearn's Naive Baye's prediction
	'''
	train  = get_features(rev_data[0])
	vals = get_features(rev_data[1])
	scaled = mmStandardize(train[0], vals[0])
	trainData = scaled[0]
	trainLabels = train[1]
	valData = scaled[1]
	valLabels = vals[1]
	gnb = GaussianNB()
	val_pred = gnb.fit(trainData, trainLabels).predict(valData)
	acc = accuracy(val_pred, valLabels)
	print "Performance : " + str(acc) + "%"

def nb_prediction(train, test, kBest):
	scaled = mmStandardize(train[0], test)
	trainFeatures = scaled[0]
	trainLabels = train[1]
	testFeatures = scaled[1]
	ch2 = SelectKBest(chi2, k=kBest)
	trainBest = ch2.fit_transform(trainFeatures, trainLabels)
	testBest = ch2.transform(testFeatures)
	selected = ch2.get_support()
	for i in range(0,len(selected)):
		if selected[i]:
			print str(i) + " feature was selected"
	gnb = GaussianNB()
	predictions = gnb.fit(trainBest, trainLabels).predict(testBest)
	return predictions

# DECISION TREE Methods
def dt_learn(rev_data):
	# Example call: p4lib.dt_learn(p4lib.get_pickeled_data()[0])
	train  = get_features(rev_data[0])
	vals = get_features(rev_data[1])
	scaled = mmStandardize(train[0], vals[0])
	trainFeatures = scaled[0]
	trainLabels = train[1]
	valFeatures = scaled[1]
	valLabels = vals[1]
	
	#clf = tree.DecisionTreeClassifier(criterion="gini", min_samples_split=leafSize)
	#clf = tree.DecisionTreeClassifier(criterion="entropy", min_samples_split=leafSize)
	clf = RandomForestClassifier(n_estimators = num_estimators, min_samples_split=leafSize)
	
	clf.fit(trainFeatures, trainLabels)
	predictions = clf.predict(valFeatures)
	acc = accuracy(predictions, valLabels)
	print "Performance : " + str(acc) + "%"
	
	# Save tree to file to visualize with Graphviz
#	with open("tree.dot", 'w') as f:
#		f = tree.export_graphviz(clf, out_file=f)

def dt_predict(train, test):
	scaled = mmStandardize(train[0], test)
	trainFeatures = scaled[0]
	trainLabels = train[1]
	testFeatures = scaled[1]
	
	#clf = tree.DecisionTreeClassifier(criterion="gini", min_samples_split=leafSize)
	#clf = tree.DecisionTreeClassifier(criterion="entropy", min_samples_split=leafSize)
	clf = RandomForestClassifier(n_estimators = num_estimators, min_samples_split=leafSize)
	
	clf.fit(trainFeatures, trainLabels)
	predictions = clf.predict(testFeatures)
	
	outFile = open("kaggle_decisiontree.txt", 'w')
	for i in predictions:
		outFile.write(str(i) + "\n")
	import StringIO
#	with open("tree.dot", 'w') as f:
#		f = tree.export_graphviz(clf, out_file=f)
	
	return predictions

def df_learn_and_predict(rev_data,test):
	train  = get_features(rev_data[0])
	vals = get_features(rev_data[1])
	scaled = mmStandardize(train[0], vals[0])
	trainFeatures = scaled[0]
	trainLabels = train[1]
	valFeatures = scaled[1]
	valLabels = vals[1]
	
	#clf = tree.DecisionTreeClassifier(criterion="gini", min_samples_split=leafSize)
	#clf = tree.DecisionTreeClassifier(criterion="entropy", min_samples_split=leafSize)
	acc=0
	while acc<71:
		clf = RandomForestClassifier(n_estimators = num_estimators, min_samples_split=leafSize)
		
		clf.fit(trainFeatures, trainLabels)
		predictions = clf.predict(valFeatures)
		acc = accuracy(predictions, valLabels)
		print "Performance : " + str(acc) + "%"
	
	tests = get_test_features(test)
	#print "size" +str(train[0].size())
	#print "size" +str(tests.size())
	scaled2 = mmStandardize(train[0], tests)
	testFeatures = scaled2[1]
	
	predictions = clf.predict(testFeatures)
	
	outFile = open("kaggle_decisiontree.txt", 'w')
	for i in predictions:
		outFile.write(str(i) + "\n")
	import StringIO
#	with open("tree.dot", 'w') as f:
#		f = tree.export_graphviz(clf, out_file=f)

# BOOSTING Methods
def boosting_performance(rev_data,test):
	# Example call: p4lib.boosting_performance(p4lib.get_pickeled_data()[0])
	train = get_features(rev_data[0])
	vals = get_features(rev_data[1])
	trainLabels = train[1]
	valLabels = vals[1]

	# get predictions from different variables 
	svmPred = svm_pred(train, vals[0], 25) # SVM 
	nbPred = nb_prediction(train, vals[0], 25) #Gaussian Naive Bayes
	dtPred = dt_predict(train, vals[0])
	
	falsePreference = []
	truthPreference = []
	majorityPreference = []
	#determine best 
	for i in range(0,len(svmPred)):
#		if svmPred[i] == nbPred[i]:
#			falsePreference.append(svmPred[i])
#			truthPreference.append(svmPred[i])
#		else:
#			falsePreference.append(0)
#			truthPreference.append(1)
		if svmPred[i]+nbPred[i]+dtPred[i] >= 1: # only deem 0 if all three are 0
			truthPreference.append(1)
		else:
			truthPreference.append(0)
			
		if svmPred[i]+nbPred[i]+dtPred[i] <= 2: # only deem 1 if all three are 1
			falsePreference.append(0)
		else:
			falsePreference.append(1)	
			
		if svmPred[i]+nbPred[i]+dtPred[i] <= 1: # two 0's and 1, or three 0's
			majorityPreference.append(0)
		else: # one 0 and two 1's, or three 1's
			majorityPreference.append(1)

	falseAcc = accuracy(falsePreference, valLabels)
	truthAcc = accuracy(truthPreference, valLabels)
	majorityAcc = accuracy(majorityPreference, valLabels)
	svmAcc = accuracy(svmPred, valLabels)
	nbAcc = accuracy(nbPred, valLabels)
	dtAcc = accuracy(dtPred, valLabels)
	print lb1
	
	tests = get_test_features(test)
	#print "size" +str(train[0].size())
	#print "size" +str(tests.size())
	scaled2 = mmStandardize(train[0], tests)
	testFeatures = scaled2[1]
	
	svmPred = svm_pred(train, testFeatures, 25) # SVM 
	nbPred = nb_prediction(train, testFeatures, 25) #Gaussian Naive Bayes
	dtPred = dt_predict(train, testFeatures)
	
	falsePreference = []
	truthPreference = []
	majorityPreference = []
	#determine best 
	for i in range(0,len(svmPred)):
#		if svmPred[i] == nbPred[i]:
#			falsePreference.append(svmPred[i])
#			truthPreference.append(svmPred[i])
#		else:
#			falsePreference.append(0)
#			truthPreference.append(1)
		if svmPred[i]+nbPred[i]+dtPred[i] >= 1: # only deem 0 if all three are 0
			truthPreference.append(1)
		else:
			truthPreference.append(0)
			
		if svmPred[i]+nbPred[i]+dtPred[i] <= 2: # only deem 1 if all three are 1
			falsePreference.append(0)
		else:
			falsePreference.append(1)	
			
		if svmPred[i]+nbPred[i]+dtPred[i] <= 1: # two 0's and 1, or three 0's
			majorityPreference.append(0)
		else: # one 0 and two 1's, or three 1's
			majorityPreference.append(1)
	
	truthFile = open("kaggle_truePref.txt", 'w')
	falseFile = open("kaggle_falsePref.txt", 'w')
	majorityFile = open("kaggle_majorityPref.txt",'w')
	svmFile = open("kaggle_svm.txt",'w')
	nbFile = open("kaggle_nb.txt",'w')
	dtFile = open("kaggle_dt.txt",'w')
	for i in truthPreference:
		truthFile.write(str(i) + "\n")
	for i in falsePreference:
		falseFile.write(str(i) + "\n")
	for i in majorityPreference:
		majorityFile.write(str(i) + "\n")
	for i in svmPred:
		svmFile.write(str(i) + "\n")
	for i in nbPred:
		nbFile.write(str(i) + "\n")
	for i in dtPred:
		dtFile.write(str(i) + "\n")
	
	print "VALIDATION ACCURACIES"
	print "SVM : " + str(svmAcc) + "%"
	print "NB : " + str(nbAcc) + "%"
	print "DT : " + str(dtAcc) + "%"	
	print "False Preference : " + str(falseAcc) + "%"
	print "Truth Preference : " + str(truthAcc) + "%"
	print "Majority Preference :" + str(majorityAcc) + "%"
	print "DT List : " + str(dtPred)