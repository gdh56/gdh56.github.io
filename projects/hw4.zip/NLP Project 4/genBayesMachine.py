'''
Created on Apr 23, 2013

@author: graham
'''
'''
Created on Apr 23, 2013

@author: graham
'''
'''
Created on Apr 21, 2013

@author: Graham Harwood
'''
'''
Created on Mar 3, 2013

@author: Graham Harwood
'''
import nltk
import nltk.tokenize 
import operator
from nltk.corpus import stopwords
import numpy
class genBayesMachine(object):
    
    def __init__(self):
        self.featCounts=list()
        self.decfeatCounts=list()
        self.decCount={'1':0,'0':0}
        self.decProbs={'1':0.0,'0':0.0}
        
        
    def setFromFeatures(self, dataList):
        self.featCounts=dict()
        self.decfeatCounts['0']=dict()
        self.decfeatCounts['1']=dict()
        for data in range(0, len(dataList)):
            for x in dataList[data]:
                self.featCounts[data]=dict()
                self.decfeatCounts[data]=dict()
                if x in self.featCounts[data]:
                    self.featCounts[data][str(x[0])]+=1
                else:
                    self.featCounts[data][x]=1
                    self.decfeatCounts[data][str(x[0])][x]=1
                if x in self.decfeatCounts[data][str(x[0])]:
                    self.decfeatCounts[data][str(x[0])][x]+=1
                else:
                    print 'unhandled'

    def setDecCounts(self, dataList):
        for data in dataList:
            for x in data:
                self.decCount[str(x[0])]+=1
                
    def setDecProbs(self):
        total=self.decCount['0']+self.decProbs['1']
        self.decProbs['0']=float(self.decCount['0'])/float(total)
        self.decProbs['1']=float(self.decCount['1'])/float(total)
        
        
                    
    def bayesProb(self, testList):
        scoreList=list()
        dProb=[0.0, 0.0]
        for test in testList:
            for x in test:
                if x in self.decfeatCounts['0']:
                    dProb[0]+=(float(self.decfeatCounts['0'][x])/float(self.decCount['0']))*self.decProbs['0']
                if x in self.decfeatCounts['1']:
                    dProb[1]+=(float(self.decfeatCounts['1'][x])/float(self.decCount['1']))*self.decProbs['1']
            if dProb[0]>dProb[1]:
                scoreList.append(0.0)
            else:
                scoreList.append(1.0)
        if numpy.average(scoreList)<.5:
            return '0'
        else:
            return '1'
        
        