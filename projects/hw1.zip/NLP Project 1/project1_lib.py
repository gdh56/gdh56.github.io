# Method library for Project 1

import nltk
import sys
import os
from nltk.corpus import stopwords
import math

linebreak1="><><><><><><><><><><><><><><><><><><><><><><><"
linebreak2="//////////////////////////////////////////////"
terminators = [".","?","!"]
badToks = ["--", "@", ">", "<"]


def removeOddCharacters(tokens):
	for tok in tokens:
		if tok in badToks:
			tokens.remove(tok)
	return tokens

def addStarters(line):
	newLine = ""
	for c in line:
		if c in terminators:
			newLine += c + " ^ "
		else:
			newLine += c
	return newLine

def removeStopWords(tokens):
	for s in stopwords.words('english'):
		if s in tokens:
			tokens.remove(s)
	return tokens

def parse_xmlfile_to_list(file_loc):
	"""Takes in a string determining the xml file location, opens the file at that location,
		creates an array of text elements from that location, and returns that array"""
	corpus = open(file_loc, "r")
	textStart = False
	text = ""
	textList = []
	for line in corpus:
		if textStart:
			if "</TEXT>" in line:
				for t in nltk.sent_tokenize(text):
					tokens = nltk.word_tokenize(t)
					tokens.insert(0, '^')
					textList.append(tokens)	
				'''tokens = nltk.word_tokenize(text)
				textList.append(tokens)'''
				textStart = False
				text = ""
			else:
				text += line

		if "<TEXT>" in line:
			textStart = True
	return textList

def parse_xmlfile_to_bigString(file_loc):
	"""Takes in a string determining the xml file location, opens the file at that location,
		creates an string, without xml tags, from that location, and returns that array
	"""
	corpus = open(file_loc, "r")
	tokens = ["^"]
	for line in corpus:
		if ("<TEXT>" not in line) and ("</TEXT>" not in line) and ("<DOC>" not in line) and ("</DOC>" not in line):
			tokens += nltk.word_tokenize(addStarters(line))
	print "Done"
	return tokens

def import_for_authDetection(file_loc):
	"""return a dictionary where the key is an author and the value is a list of strings where
		each string represents an email
	"""
	print linebreak2
	print "Importing for Author Detection"
	print linebreak2
	numEmails = 0
	numAuthors = 0
	corpus = open(file_loc, "r")

	authEmails = dict()
	for line in corpus:
		author = line[:line.find(" ")].strip()
		email = line[line.find(" "):]
		numEmails += 1
		if author in authEmails.keys():
			#print "email added"
			authEmails[author].append(email)
			type(authEmails[author])
		else:
			#print "adding author"
			authEmails[author] = []
			authEmails[author].append(email)
			numAuthors += 1
	print "Importing is done"
	print linebreak2
	return authEmails

def import_unknownEmails(file_loc):
	fileInput = open(file_loc, "rb")
	unknownList = []
	for line in fileInput:
		unknownList.append(line)
	fileInput.close()
	return unknownList


# +1 smoothing
# Takes in a dictionary and tTokens= the total number of tokens in the inserted corpora
# Returns a +1 smoothed dictionary
def smooth(aDict, tTokens):
	denom=tTokens + len(aDict) #Takes care of the sum of tokens plus the add on for smoothing
	for x in aDict:
		aDict[x]=aDict[x] + 1.0
		aDict[x]=aDict[x]/denom
	return aDict

def perplexity(model, theText):
	rSum=0.0
	theText=nltk.word_tokenize(theText)
	for x in theText:
		if x in model:
			rSum=rSum + abs(math.log(model[x]))
		else:
			rSum+=10.0
	rSum=(1.0/len(theText))*rSum
	return math.pow(2.0,rSum)

# Good Turing Smoothing
# Takes in a dictionary and tTokens= the total number of tokens in the inserted corpora
# Returns a good Turing Smoothed dictionary of probabilities
def tSmooth(aDict, tTokens):
	numer=tTokens + len(aDict) #Takes care of the sum of tokens plus the add on for smoothing
	rSum=0
	for x in aDict:
		c=aDict[x]
		aDict[x]=(c+1.0)*(numer/tTokens)
		rSum=rSum+aDict[x]
	for x in aDict:
		aDict[x]=aDict[x]/rSum
	return aDict   



# Simple author comparison using a somewhat normalized similarity based on the number 
# of words that are similar between the two corporas
# @param aDict: The known author corpora keys and values
# @param bDict: The unknown corpora keys and values
# @return: Euclidean distance between the two sets
def simpleAuthCompare(aDict, bDict):
	counter=0
	for x in bDict:
		if x in aDict:
			counter+=1.0
	similarity=counter/len(aDict)
	return similarity

def differencesCompare(aFreq, unknownDict):
	uFreq = nltk.FreqDist(nltk.word_tokenize(unknownDict))
	score = 0
	for uWord in uFreq:
		if uWord in aFreq:
			#print "existing word"
			score += abs(aFreq.freq(uWord) - uFreq.freq(uWord))
		else:
			#print "new word"
			score += uFreq.freq(uWord)

	if score != 0:
		score = 1/score
	return score

def bigramDifferencesCompare(aFreq, unknownDict):
	uBiFreq = nltk.FreqDist(nltk.bigrams(nltk.word_tokenize(unknownDict)))
	score = 0
	for uWord in uBiFreq:
		if uWord in aFreq:
			#print "existing word"
			score += abs(aFreq.freq(uWord) - uBiFreq.freq(uWord))
		else:
			#print "new word"
			score += uBiFreq.freq(uWord)

	if score != 0:
		score = 1/score
	return score

# This is essentially pseudo code for a euclidean distance comparison
# The best fitting will be the dictionary that has the minimum 
# Words that don't overlap with the known corpora are just inserted 
# which is the equivalence of adding their distance from 0 smallest total return is best match
# @param aDict: The known author corpora keys and values
# @param bDict: The unknown corpora keys and values
# @return: the inverse of the Euclidean distance between the two sets
def euclidDistCompare(aDict, bDict):
	total=0
	for x in bDict:
		if x in aDict:
			temp=math.sqrt(abs(math.pow(bDict[x],2)-math.pow(aDict[x],2)))
			total+=temp
		else:
			total+=bDict[x]
	return 1/total

def genSentence(gram):
	sentence = ''
	numWords = 0
	word = ''
	
	if gram.n is 1:
		while (word not in terminators) and (numWords < 100):
			word = gram.sampleFrom(gram.wordCount)
			if word != "^":
				sentence += word + " "
				numWords += 1
		print sentence

	else:
		prevWord = '^'
		while (word not in terminators) and (numWords < 100):
			bigrams = gram.bigramsStartingWith(prevWord)
			if len(bigrams) is 0: # No bigrams starting with prevWord
				word = gram.sampleFrom(gram.wordCounts)
			else:
				nextgram = gram.sampleFrom(bigrams)
				if nextgram == '<UNSEEN>':
					word = gram.sampleUnknownBigram(bigrams)
				else:
					word = nextgram[1]
			sentence += word + ' '
			numWords += 1
			prevWord = word
		if len(sentence) is 1:
			genSentence(gram)
		else:
			print sentence
		
def addTokToDict(unigramSet, tokens):
	fDist = nltk.FreqDist(tokens)
	for tok in tokens:
		unigramSet[tok] = fDist.freq(tok)
	return unigramSet
	#for x in tokens:
	#	if x in unigramSet:
	#		unigramSet[x]=unigramSet[x] + 1.0
	#	else:
	#		unigramSet[x]=1.0
	#return unigramSet

def stringToDict(givenString):
	tokens = nltk.word_tokenize(givenString)
	unigramSet=dict()
	for x in tokens:
		if x in unigramSet:
			unigramSet[x]=unigramSet[x] + 1.0
		else:
			unigramSet[x]=1.0
		return unigramSet


def authorToDict(aDict):
	authorModels = {}
	for author in aDict:
		authorString = ""
		for s in aDict[author]:
			authorString += s

		#tokenedStrings=nltk.batch_tokenize(aDict[author])
		tokenedString = removeOddCharacters(nltk.word_tokenize(authorString))
		#authorModels[author] = addTokToDict(authorDict, tokenedString)
		authorModels[author] = nltk.FreqDist(tokenedString)
		i = 0
		print author + "'s most frequent words"
		for sample in authorModels[author]:
			print str(i) + ") " + sample + " : " + str(authorModels[author].freq(sample))
			if i > 6:
				break
			else:
				i += 1
	return authorModels


def authorToBiDict(aDict):
	authorModels = {}
	for author in aDict:
		authorString = ""
		for s in aDict[author]:
			authorString += s

		#tokenedStrings=nltk.batch_tokenize(aDict[author])
		tokenedString = nltk.bigrams(removeOddCharacters(nltk.word_tokenize(authorString)))
		#authorModels[author] = addTokToDict(authorDict, tokenedString)
		authorModels[author] = nltk.FreqDist(tokenedString)
		i = 0
		print author + "'s most frequent bigrams"
		for sample in authorModels[author]:
			print str(i) + ") " + sample[0] + ", " + sample[1] + " : " + str(authorModels[author].freq(sample))
			if i > 6:
				break
			else:
				i += 1
	return authorModels

def emailMatch(aDict, unknownEmail):
	score = 0
	author = "unkown"
	for aut in aDict:
		autScore = bigramDifferencesCompare(aDict[aut], unknownEmail)
		#print 'Score : ' + str(autScore)
		if autScore > score:
			score = autScore
			author = aut
	#print author + " is best match, Score : " + str(score)
	return author


def betterMatch(aDict, biDict, unknownEmail):
	score = 0
	author = "unkown"
	for aut in aDict:
		autUniScore = differencesCompare(aDict[aut], unknownEmail)
		autBiScore = bigramDifferencesCompare(biDict[aut], unknownEmail)
		autScore = autUniScore + autBiScore
		#print 'Score : ' + str(autScore)
		if autScore > score:
			score = autScore
			author = aut
	#print author + " is best match, Score : " + str(score)
	return author

#	minScore=999999999999999
#	emailDict=stringToDict(unknownEmail)
#	for aut in aDict:
#		score=simpleAuthCompare(aDict[aut], emailDict)
#		if score<=minScore:
#			minScore=score
#			bestAuthor=aut
#	print "Score : " + str(score)
#	return bestAuthor

def betterMatchMaker(emailList, aDict, biDict):
	filename="results.txt"
	#exists=os.path.exists(filename)
	if os.path.exists(filename):
		os.remove(filename)
		output=open(filename, "a")
	for email in emailList:
		theBestAuthor=betterMatch(aDict, biDict, email)
		#print theBestAuthor
		output.write(theBestAuthor + "\n")

def matchMaker(emailList, aDict, biDict):
	filename="results.txt"
	#exists=os.path.exists(filename)
	if os.path.exists(filename):
		os.remove(filename)
		output=open(filename, "a")
	for email in emailList:
		theBestAuthor=emailMatch(aDict, email)
		#print theBestAuthor
		output.write(theBestAuthor + "\n")

		
		
		



