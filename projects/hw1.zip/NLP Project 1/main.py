'''
Created Feb. 23
@author: Scott Cambo, Graham Harwood, Jennifer Doughty, Malcolm Mckinney

CS 4740 : Natural Language Processing
Project 1

'''

import pickle
import sys
from Model import NGram
import project1_lib as p1

wsj_loc = "../texts/wsj/wsj.train"
movie_loc = "../texts/movie/movie.train"
linebreak1="><><><><><><><><><><><><><><><><><><><><><><><"
linebreak2="//////////////////////////////////////////////"
linebreak3="----------------------------------------------"


'''def printStats(gram):
	print linebreak3
	print 'Word Count: ' + str(gram.wordCounts)

	print linebreak3'''

'''def printSmoothStats(gram):
	print 'Smoothed Word Count: ' + str(gram.wordCounts)'''

def act1():
	#Sentence Generation
	print linebreak2
	print "1. Sentence Generation"
	print linebreak3
	answer = raw_input("Is there already a model for this data that you would like to use? Y or N\n")
	if answer.lower() == "y":
		model = raw_input("Please type the location and name of the model file below.\n")
		gram = pickle.load(open(model, "rb"))
		print linebreak3
		'''printStats(gram)
		print linebreak3'''
	else:
		#print "First, we will define a text file for training"
		#file_loc = raw_input("Please type the file location and press ENTER\n")
		#print linebreak3
		#print "File : " + file_loc
		#print linebreak3
		
		print "Please choose from one or both of the following texts to train on"
		print "1) Movie Reviews"
		print "2) Wall Street Journal Articles"
		print "3) Both"
		answer = raw_input("Please type 1, 2, or 3 and press ENTER\n")
		if answer is "1":
			print "Importing data"
			train1 = p1.parse_xmlfile_to_list(movie_loc)
			print "Data imported"
		elif answer is "2":
			print "Importing data"
			train1 = p1.parse_xmlfile_to_list(wsj_loc)
			print "Data imported"
		elif answer is "3":
			print "Importing data"
			train1 = p1.parse_xmlfile_to_list(movie_loc)
			train1 += p1.parse_xmlfile_to_list(wsj_loc)
			print "Data imported"
		print linebreak3
		print "Now, we need to train an N-gram model on the data.  What should n be?"
		n = int(raw_input("Type a value for n below and Press ENTER\n"))
		print "Training " + str(n) + "-gram model..."
		gram = NGram(n)
		gram.trainOnTexts(train1)
		print "Training is done"
		#printStats(gram)
		print "Shall we smooth this data?"
		inpt = raw_input("Type S for smoothing, T for turing smoothing, or N for no smoothing below and press ENTER\n")
		if inpt.lower() is "s":
			if gram.n >= 2:
				p1.smooth(gram.bigramCounts, gram.numWords)
			if gram.n is 3:
				p1.smooth(gram.trigramCounts, gram.numWords)
			#printSmoothStats(gram)
		elif inpt.lower() is "t":
			if gram.n >= 2:
				p1.tSmooth(gram.bigramCounts, gram.numWords)
			if gram.n is 3:
				p1.tSmooth(gram.trigramCounts, gram.numWords)
			#printSmoothStats(gram)
		print linebreak3
		inpt = raw_input("Save model for later use? Y or N\n")
		if inpt.lower() == "y":
			output_loc = raw_input("What is the file location and name?")
			pickle.dump(gram, open(output_loc, "wb"))

	print "generating sentence"
	answer = "y"
	while answer.lower() == "y":
			p1.genSentence(gram)
			answer = raw_input("Would you like to print another sentence? Y or N\n")

def act2():
	# import training set
	print linebreak2
	print "1. Author Detection"
	print linebreak3

	print "First, we will need a training set for author detection."
	file_loc = raw_input("Define a file location and name below\n")
	trainEmails = p1.import_for_authDetection(file_loc)
	print "Authors are :"
	for t in trainEmails.keys():
		print "\t" + t
	print "Next, a validation set:"
	val_loc= raw_input("Define a location for validation set\n")
	unknownList = p1.import_unknownEmails(val_loc)
	print "Next, we will take in our test set"
	test_loc = raw_input("Define a file location and name below\n")
	unknownList =unknownList + p1.import_unknownEmails(test_loc)
	print linebreak3
	print "Training emails"
	authorBiModels = p1.authorToBiDict(trainEmails)
	authorModels = p1.authorToDict(trainEmails)
	print "Training done"
	print linebreak3
	print "Matching emails"
	p1.betterMatchMaker(unknownList, authorModels, authorBiModels)
	# test training set

def act3():
	print linebreak2
	print "3. Perplexity Calculator"
	print linebreak3
	print ""
        model = raw_input("Please type the file name of the model you would like to load.\n")
        gram = pickle.load(open(model, "rb"))
        print linebreak3
                
	model= gram.wordCounts
	print "Please type in the string you would like to compare:"
	theText= raw_input("String:")
	print linebreak2
	print "Perplexity: " + str(p1.perplexity(model, theText))
	print "Would you like to calculate perplexity for another sentence?"
	yn= raw_input("(Y/N)")
	while yn.lower() == "y":
		print "Please type in the string you would like to compare:"
		theText= raw_input("String:")
		print linebreak2
		print "Perplexity: " + str(p1.perplexity(model, theText))
		print "Would you like to calculate perplexity for another sentence?"
		yn= raw_input("(Y/N)")
		
if __name__ == '__main__':
	
	print linebreak1
	print "Welcome to our NLP Project 1"
	print linebreak1

	activity = 0
	while (activity is not 1) and (activity is not 2) and (activity is not 3):
		print "Please select an activity"
		print "1. Sentence Generation"
		print "2. Author Detection"
		print "3. Perplexity Calculator"
		activity = int(raw_input("Type 1, 2, or 3 and press ENTER\n"))
		if activity == 1:
			act1()
		elif activity == 2:
			act2()
		elif activity== 3:
			act3()
