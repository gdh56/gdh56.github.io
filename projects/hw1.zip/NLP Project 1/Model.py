'''
Created on Feb 19, 2013

@author: Jennifer
'''
from __future__ import division
from collections import Counter
from sets import Set
import random

class NGram(object):

    def __init__(self,numGrams):
        '''
        Constructor
        '''
        self.n=numGrams # n=1 unigram, n=2 bigram, etc.
        self.wordCounts=Counter() # dictionary keys=words, vals=counts
        self.bigramCounts=Counter() # dictionary keys=tuples size 2, vals=counts
        self.trigramCounts=Counter() # dictionary keys=tuples size 3, vals=counts
        self.numWords=0 # Number of tokens in text
        
    def trainOnTexts(self,texts):
        '''
        Given a list of texts, computes the count statistics.
        Texts argument is a list of lists of word tokens.
        '''
        if self.n is 1: # Unigram case
            for t in texts:
                self.numWords += len(t)
                self.wordCounts += Counter(t)
        if self.n is 2: # Bigram case
            for t in texts:
                self.numWords += len(t)
                self.wordCounts += Counter(t)
                self.bigramCounts += Counter((x,y) for x, y in zip(*[t[i:] for i in range(2)]))
            num = len(self.wordCounts)
            self.bigramCounts['<UNSEEN>'] = num*num - len(self.bigramCounts)
        if self.n is 3: # Trigram case
            for t in texts:
                self.numWords += len(t)
                self.wordCounts += Counter(t)
                self.bigramCounts += Counter((x,y) for x, y in zip(*[t[i:] for i in range(2)]))
                self.trigramCounts += Counter((x,y,z) for x, y, z in zip(*[t[i:] for i in range(3)]))
            num = len(self.wordCounts)
            self.bigramCounts['<UNSEEN>'] = num*num - len(self.bigramCounts)
            self.trigramCounts['<UNSEEN>'] = num*num*num - len(self.trigramCounts)
    
    def bigramsStartingWith(self,word):
        tuples = Counter()
        for tup in self.bigramCounts.keys():
            if tup[0] == word:
                tuples[tup]=self.bigramCounts[tup]
        tuples['<UNSEEN>'] = len(self.wordCounts) - len(tuples)
        return tuples
    
    def trigramsStartingWith(self,word):
        tuples = Counter()
        for tup in self.trigramCounts.keys():
            if tup[0] is word:
                tuples[tup]=self.trigramCounts[tup]
        tuples['<UNSEEN>'] = len(self.wordCounts)*len(self.wordCounts) - len(tuples)
    
    def sampleFrom(self,weightedDict):
        rnd = random.random() * sum(weightedDict.values())
        for key, w in weightedDict.iteritems():
            rnd -= w
            if rnd <= 0:
                return key
            
    def sampleUnknownBigram(self,weightedDict):
        s = Set([])
        for key in weightedDict.keys():
            s.add(key[1])
        samplingSet = Set(self.wordCounts.keys()) - s
        return self.sampleFrom({x: 1 for x in samplingSet})