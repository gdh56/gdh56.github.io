'''
Created on Feb 19, 2013

@author: Jennifer
'''
from Model import NGram

if __name__ == '__main__':
    
    n = 1
    print 'n = ' + str(n)
    gram = NGram(n)
    text = ['A','B','C','A','D','A','B']
    gram.trainOnText(text)
    print 'Word Count: ' + str(gram.wordCount)
    print 'Tuple Count: ' + str(gram.tupleCount)
    print 'Small Tuple Count: ' + str(gram.smallTupleCount)
    print '---SMOOTHING---'
    gram.smootheAddOne()
    print 'Smoothed Tuple Count: ' + str(gram.tupleCount)
    print 'Smoothed Small Tuple Count: ' + str(gram.smallTupleCount)
    print 'Prob(B) = ' + str(gram.prob('B'))
    print 'Prob(A) =' + str(gram.prob('A'))
    
    print '----------------'
    
    
    n = 2
    print 'n = ' + str(n)
    gram = NGram(n)
    text = ['A','B','C','A','D','A','B']
    gram.trainOnText(text)
    print 'Word Count: ' + str(gram.wordCount)
    print 'Tuple Count: ' + str(gram.tupleCount)
    print 'Small Tuple Count: ' + str(gram.smallTupleCount)
    print '---SMOOTHING---'
    gram.smootheAddOne()
    print 'Smoothed Tuple Count: ' + str(gram.tupleCount)
    print 'Smoothed Small Tuple Count: ' + str(gram.smallTupleCount)
    print 'Prob(B|A) = ' + str(gram.prob('B','A'))
    print 'Prob(B) = ' + str(gram.prob('B'))
    print 'Prob(A,B) = ' + str(gram.prob(('A','B')))
    
    print '----------------'
    
    n += 1
    print 'n = ' + str(n)
    gram = NGram(n)
    gram.trainOnText(text)
    print 'Word Count: ' + str(gram.wordCount)
    print 'Tuple Count: ' + str(gram.tupleCount)
    print 'Small Tuple Count: ' + str(gram.smallTupleCount)
    print '---SMOOTHING---'
    gram.smootheAddOne()
    print 'Smoothed Tuple Count: ' + str(gram.tupleCount)
    print 'Smoothed Small Tuple Count: ' + str(gram.smallTupleCount)
    print 'Prob(C|AB) = ' + str(gram.prob('C',('A','B')))
    print 'Prob(B) = ' + str(gram.prob('B'))
    print 'Prob(A,B,C) = ' + str(gram.prob(('A','B','C')))
    
    print '----------------'
    
    n += 1
    print 'n = ' + str(n)
    gram = NGram(n)
    gram.trainOnText(text)
    print 'Word Count: ' + str(gram.wordCount)
    print 'Tuple Count: ' + str(gram.tupleCount)
    print 'Small Tuple Count: ' + str(gram.smallTupleCount)
    print '---SMOOTHING---'
    gram.smootheAddOne()
    print 'Smoothed Tuple Count: ' + str(gram.tupleCount)
    print 'Smoothed Small Tuple Count: ' + str(gram.smallTupleCount)
    print 'Prob(A|ABC) = ' + str(gram.prob('A',('A','B','C')))
    print 'Prob(B) = ' + str(gram.prob('B'))
    print 'Prob(A,B,C) = ' + str(gram.prob(('A','B','C')))
    print 'Prob(A,B,C,A) = ' + str(gram.prob(('A','B','C','A')))
    
    print '----------------'
    
    n = 2
    print 'n = ' + str(n)
    gram = NGram(n)
    text2 = ['C','B','C','B','C','B','C']
    gram.trainOnTexts([text,text2])
    print 'Word Count: ' + str(gram.wordCount)
    print 'Tuple Count: ' + str(gram.tupleCount)
    print 'Small Tuple Count: ' + str(gram.smallTupleCount)
    print '---SMOOTHING---'
    gram.smootheAddOne()
    print 'Smoothed Tuple Count: ' + str(gram.tupleCount)
    print 'Smoothed Small Tuple Count: ' + str(gram.smallTupleCount)
    print 'Prob(B|A) = ' + str(gram.prob('B','A'))
    print 'Prob(B) = ' + str(gram.prob('B'))
    print 'Prob(A,B) = ' + str(gram.prob(('A','B')))
    
    #gram.randomSentences()