import nltk
import nltk.tokenize
import math


# +1 smoothing
# Takes in a dictionary and tTokens= the total number of tokens in the inserted corpora
# Returns a +1 smoothed dictionary
def smooth(aDict, tTokens):
    denom=tTokens + len(aDict) #Takes care of the sum of tokens plus the add on for smoothing
    for x in aDict:
        aDict[x]=aDict[x] + 1.0
        aDict[x]=aDict[x]/denom
    return aDict
#@param model: the Ngram model
#@param theText: The incoming text can be taken as either a list or a dict
def perplexity(model, theText):
    rSum=0
    for x in theText:
        rSum=rSum + math.log10(model[x])
    rSum=(-1/len(theText))*rSum    
    return math.pow(2,rSum)
            
# Good Turing Smoothing
# Takes in a dictionary and tTokens= the total number of tokens in the inserted corpora
# Returns a good Turing Smoothed dictionary of probabilities
def tSmooth(aDict, tTokens):
    numer=tTokens + len(aDict) #Takes care of the sum of tokens plus the add on for smoothing
    rSum=0
    for x in aDict:
        c=aDict[x]
        aDict[x]=(c+1.0)*(numer/tTokens)
        rSum=rSum+aDict[x]
    for x in aDict:
        aDict[x]=aDict[x]/rSum
    return aDict   




# Simple author comparison using a somewhat normalized similarity based on the number 
# of words that are similar between the two corporas
# @param aDict: The known author corpora keys and values
# @param bDict: The unknown corpora keys and values
# @return: Euclidean distance between the two sets
def simpleAuthCompare(aDict, bDict):
    counter=0
    for x in bDict:
        if x in aDict:
            counter+=1.0
    similarity=counter/len(aDict)
    return similarity

# This is essentially pseudo code for a euclidean distance comparison
# The best fitting will be the dictionary that has the minimum 
# Words that don't overlap with the known corpora are just inserted 
# which is the equivalence of adding their distance from 0 smallest total return is best match
# @param aDict: The known author corpora keys and values
# @param bDict: The unknown corpora keys and values
# @return: the inverse of the Euclidean distance between the two sets
def euclidDistCompare(aDict, bDict):
    total=0
    for x in bDict:
        if x in aDict:
            temp=math.sqrt(abs(math.pow(bDict[x],2)-math.pow(aDict[x],2)))
            total+=temp
        else:
            total+=bDict[x]
    return 1/total

def toDictFromTok(strings):
    unigramSet=dict()
    tokens = nltk.word_tokenize(strings)
    for x in tokens:
        if x in unigramSet:
            unigramSet[x]=unigramSet[x] + 1.0
        else:
            unigramSet[x]=1.0
    return unigramSet


def toTestSmoothAdd(smoothedDict):
    dracula=0
    for x in smoothedDict:
        dracula+=smoothedDict[x]
    return dracula
    
    
test2="na na na na na thunderstruck you've been I am shaking at the knees malcolm is a doo doo head"
test3="long string that may or may not be thunderstruck"
test4= "unlike anything you've ever seen"        
test="this is a long string that should not cause the the program to crash"

testDict=toDictFromTok(test)
testDict2=toDictFromTok(test2)
testDict3=toDictFromTok(test3)
testDict4=toDictFromTok(test4)
sDict=smooth(testDict2, 21)
tDict=tSmooth(testDict2, 21)
print sDict
print tDict
print toTestSmoothAdd(sDict)
print toTestSmoothAdd(tDict)

